/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <SERCOM_UART.h>


void SERCOMUART_Init (void)
{
    /*****************SERCOM_UART clock configuration *********************/
    /* Select AHBC bus clk for SERCOM3 */    
    REGDW(PM_APBCMASK_REG) |= PM_APBCMASK_SERC0M3;
    
    /* Select Generater0 and set CLK enable bit*/
    REGW(GCLK_CLKCTRL_REG) = (GCLK_CLKCTRL_ID(GCLK_CLKCTRL_ID_SERCOM3_CORE) | 
                                GCLK_CLKCTRL_GEN(GCLK_CLKCTRL_GEN_GCLK0_Val) | 
                                (GCLK_CLKCTRL_CLKEN));
    
    /* Wait Until SYNCBUSY bit to clear*/
    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
    
    /******************SERCOM_UART Register Configuration ***************/
    
    /* Soft Reset*/
    REGW(SERCOM_UART_CTRLA_REG) = SERCOM_UART_CTRLA_SWRST;
    
    /* Synchronization Wait Until SYNCBUSY bit to clear */
    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
    
  
    /*************** CTRLA register configuration ******************************* 
     *  MODE    - 0x1   Internal clock 
     *  CMODE   - 0x0   Asynchronous mode
     *  RXPO    - 0x03  SERCOM PAD[3]
     *  TXPO    - 0x02  SERCOM PAD[3]
     *  DORD    - 0x01  MSB first 
    ***************************************************************************/
    
    REGDW(SERCOM_UART_CTRLA_REG) = (SERCOM_UART_CTRLA_DORD 
									| SERCOM_UART_CTRLA_TXPO_SERCOM_PAD2
                                    | SERCOM_UART_CTRLA_RXPO_SERCOM_PAD3
									| SERCOM_UART_CTRLA_MODE_INT_CLK);
     
     /*************** CTRLB register configuration ******************************* 
     *  CHSIZE  - 0x0   Character Size to 8 bit 
     *  SBMODE  - 0x0   One Stop bit
     *  TXEN    - 0x01  Transmitter Enable
     *  RXEN    - 0x01  Receiver Enable
    ***************************************************************************/
    
     REGDW(SERCOM_UART_CTRLB_REG) = (SERCOM_UART_CTRLB_TXEN | SERCOM_UART_CTRLB_RXEN);
            
    /* BAUD Register*/
	 REGW(SERCOM_UART_BAUD_REG) = SERCOM_UART_BAUD_REG_VALUE(SERCOM_UART_BAUDRATE);
	 
    /******************SERCOM_UART Port Configuration ********************/
	 
	GPIO_SetPinFunction (PIN_PA18, PINMUX_PA18D_SERCOM3_PAD2);
	
	GPIO_SetPinFunction (PIN_PA19, PINMUX_PA19D_SERCOM3_PAD3);
	
	/* Enable UART*/
	REGDW(SERCOM_UART_CTRLA_REG) |= SERCOM_UART_CTRLA_ENABLE;
}

/**********************************************************************************/

void SERCOMUART_WriteChar (UINT8 u8WriteChar)
{
	/*Wait till Data register to empty*/
	while((REGB(SERCOM_UART_INTFLAG_REG) & SERCOM_UART_INTFLAG_DRE) == 0);
	
	/* Write buffer data bytes to DATA register*/
	REGB(SERCOM_UART_DATA_REG) = u8WriteChar;
	
	/*Wait till Data register to empty*/
	while((REGB(SERCOM_UART_INTFLAG_REG) & SERCOM_UART_INTFLAG_DRE) == 0);
    
}

/**********************************************************************************/

UINT8 SERCOMUART_ReadChar(void)
{
	/* Wait till Receive interuupt occurs*/
    while((REGB(SERCOM_UART_INTFLAG_REG) & SERCOM_UART_INTFLAG_RXC) == 0)
    {
        
    }
        
    /* return the data in buffer*/
	return (REGB(SERCOM_UART_DATA_REG));
	
}

/**********************************************************************************/

CHAR SERCOMUART_HexToAscii (UINT8 u8Val)
{
	if (u8Val <= 9)
	{
	  	/* if value is from 0 to 9, add '0'*/
		u8Val += '0';
	}
	else if ((u8Val >= 0xA) && (u8Val <= 0xF))
	{
	  	/* if value is from 0xA to 0xF, add 'A' & subtract 0xA*/
		u8Val += ('A' - 0xA);
	}

	return u8Val;
}

/**********************************************************************************/

void SERCOMUART_WriteUINT8 (UINT8 u8Val)
{
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u8Val >> 4) & 0x0F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u8Val >> 0) & 0x0F));
	SERCOMUART_WriteChar (' ');
}

/**********************************************************************************/

void SERCOMUART_WriteUINT16 (UINT16 u16Val)
{
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u16Val >> 12) & 0x000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u16Val >>  8) & 0x000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u16Val >>  4) & 0x000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u16Val >>  0) & 0x000F));
	SERCOMUART_WriteChar (' ');
}

/**********************************************************************************/

void SERCOMUART_WriteUINT32 (UINT32 u32Val)
{
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >> 28) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >> 24) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >> 20) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >> 16) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >> 12) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >>  8) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >>  4) & 0x0000000F));
	SERCOMUART_WriteChar (SERCOMUART_HexToAscii ((u32Val >>  0) & 0x0000000F));
	SERCOMUART_WriteChar (' ');
}

/**********************************************************************************/

void SERCOMUART_WriteString (const CHAR *pszMessage)
{
	while (*pszMessage != SET_TO_ZERO)
	{
		SERCOMUART_WriteChar (*pszMessage);
		pszMessage++;
	}
	
#ifndef MCHP_TRACE    
	SERCOMUART_WriteChar (' ');
#endif

}

/**********************************************************************************/


void SERCOMUART_IntegerToString (INT32 i32nbr, CHAR *pchInt) 
{
    INT32 i32numChars = 0;
    INT32 i32Index = i32nbr;
	
	/* number of characters in i32nbr is counted & updated to i32numChars*/
    do 
    {
        i32numChars++;
        i32Index /= 10;
        
    } while ( i32Index );
    
	/* NULL is stored to last index*/
    pchInt[i32numChars] = 0;

    i32Index = i32numChars - 1;
    
	/* i32nbr is converted to ASCII & stored in ppchInt*/
    do 
    {
        pchInt[i32Index--] = (i32nbr % 10) + '0';
        i32nbr /= 10;
        
    } while (i32nbr);
    
}

/**********************************************************************************/

void SERCOMUART_WriteINT32 (INT32 i32nbr)
{
    CHAR chBuffer[8];
    
    SERCOMUART_IntegerToString (i32nbr,&chBuffer[0]);
    
    SERCOMUART_WriteString (chBuffer);
    
    SERCOMUART_WriteChar (' ');
}

/**********************************************************************************/

