/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/


#include <stdinc.h>
#include <portpower_control.h>
#include <dac.h>

static void UPD_GPIOGenericOutputInit(UINT8 u8PortNum,UINT8 u8PIONum, UINT8 u8PioMode);

static void UPD_GPIOGenericOutputInit(UINT8 u8PortNum,UINT8 u8PIONum, UINT8 u8PioMode)
{
    if (UPD_PIO_UN_DEF != u8PIONum)
    {
        /*clear bits 6:4 and 1:0 in the read value to avoid invalid combinations.*/
        u8PioMode &= (UPD_GPIO_PULL_UP_ENABLE | UPD_GPIO_DATAOUTPUT | UPD_GPIO_BUFFER);
        /*enable GPIO and direction as output*/
        u8PioMode |= (UPD_GPIO_DIRECTION | UPD_GPIO_ENABLE);
        /*de-assert the pin*/
        u8PioMode ^= UPD_GPIO_DATAOUTPUT;
        /*update the value to GPIO register.*/
        UPD_RegWriteByte(u8PortNum, UPD_CFG_PIO_REGADDR(u8PIONum), u8PioMode);
    }
}
/***********************************************************************************/

void PWRCTRL_initialization(UINT8 u8PortNum)
{
  

    UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, \
                                    gasUpdPioConfigData[u8PortNum].u8VBUSEnPioMode);

    UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, \
                                        gasUpdPioConfigData[u8PortNum].u8VBUSDisPioMode);
    
    if (u8PortNum == PORT0)
    {
        (void)DAC_Initialization();
    }
    else if(u8PortNum == PORT1)
    {

        UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8DcDcEnPio, \
                                        gasUpdPioConfigData[u8PortNum].u8DcDcEnPioMode);

        UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode);
        
        UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode);
        
        UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode);
        
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8DcDcEnPio, \
                gasUpdPioConfigData[u8PortNum].u8DcDcEnPioMode, UPD_GPIO_ASSERT);
    }

}
/************************************************************************************/
void PWRCTRL_SetPortPower (UINT8 u8PortNum, UINT8 u8PDOIndex, UINT16 u16VBUSVoltage, UINT16 u16Current)
{
    UINT8 u8EnVbusMode = gasUpdPioConfigData[u8PortNum].u8VBUSEnPioMode;
    
    if ((PWRCTRL_VBUS_0V == u16VBUSVoltage) || \
                (!(UPD_RegReadWord (u8PortNum, UPD_PIO_STS) & \
                                BIT(gasUpdPioConfigData[u8PortNum].u8FaultInPio))))
    {
        /*Drive EN_VBUS low when driving VBUS zero*/
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, 
                u8EnVbusMode, UPD_GPIO_DE_ASSERT);
    }
    else
    {
        /*Drive EN_VBUS high when driving VBUS high*/
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, 
                u8EnVbusMode, UPD_GPIO_ASSERT);
    }

    if(PORT0 == u8PortNum)
    {
        (void)DAC_DriveVoltage(u16VBUSVoltage);
    }

    else if (1 == u8PortNum)
    {
         UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode, \
                 ((gasUpdPioConfigData[u8PortNum].u8VSELmapforPDO[u8PDOIndex] & BIT0) == BIT0)
                 ?UPD_GPIO_ASSERT:UPD_GPIO_DE_ASSERT);
         
         UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode, \
                 ((gasUpdPioConfigData[u8PortNum].u8VSELmapforPDO[u8PDOIndex] & BIT1) == BIT1)
                 ?UPD_GPIO_ASSERT:UPD_GPIO_DE_ASSERT);
         
         UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode, \
                  ((gasUpdPioConfigData[u8PortNum].u8VSELmapforPDO[u8PDOIndex] & BIT2) == BIT2)
                 ?UPD_GPIO_ASSERT:UPD_GPIO_DE_ASSERT);
        
    }
}

void PWRCTRL_ConfigVBUSDischarge (UINT8 u8PortNum, UINT8 u8EnaDisVBUSDIS)
{
    UINT8 u8VbusDisMode = gasUpdPioConfigData[u8PortNum].u8VBUSDisPioMode;
    
    if (u8EnaDisVBUSDIS == PWRCTRL_ENABLE_VBUSDIS )
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, u8VbusDisMode, UPD_GPIO_ASSERT);
    }
    else
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, u8VbusDisMode, UPD_GPIO_DE_ASSERT);
    }

}


