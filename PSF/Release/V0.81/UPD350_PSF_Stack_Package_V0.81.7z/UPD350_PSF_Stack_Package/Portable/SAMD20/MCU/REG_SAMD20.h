/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
/*******************************************************************************
  SAMD20 Register definitions

  Company:
    Microchip Technology Inc.

  File Name:
    REG_SAMD20.h

  Summary:
    This file contains all the register definition in SAM D20

  Description:
    This header file contains definitions for all the registers in SAM d20
*******************************************************************************/

#ifndef _REG_SAMD20_H
#define _REG_SAMD20_H

#include <stdinc.h>


/*********************************************/

#define CPU_FREQUENCY               48000000

/***********Register base address*********************/

#define GCLK_REGBASE                (0x40000C00)
#define PM_REGBASE                  (0x40000400)    /* brief (PM) APB Base Address */
#define SERCOM_REGBASE 	            (0x42000800) /*  SERCOM base address*/

/***************GCLK Registers************************/

#define GCLK_CLKCTRL_REG            (GCLK_REGBASE + 0x02)

#define GCLK_CLKCTRL_ID_Pos         0          /* Generic Clock Selection ID */
//#define GCLK_CLKCTRL_ID_Msk         ((0x3F) << GCLK_CLKCTRL_ID_Pos)
#define GCLK_CLKCTRL_ID(value)      (GCLK_CLKCTRL_ID_Msk & ((value) << GCLK_CLKCTRL_ID_Pos))

#define GCLK_CLKCTRL_GEN_Pos        8            /* Generic Clock Generator */
//#define GCLK_CLKCTRL_GEN_Msk        ((0xF) << GCLK_CLKCTRL_GEN_Pos)
#define GCLK_CLKCTRL_GEN(value)     (GCLK_CLKCTRL_GEN_Msk & ((value) << GCLK_CLKCTRL_GEN_Pos))
//#define GCLK_CLKCTRL_GEN_GCLK0_Val   (0x0)   /**< \brief (GCLK_CLKCTRL) Generic clock generator 0 */

#define CLKCTRL_GEN_GCLK0_Val   (0x0)
//#define GCLK_CLKCTRL_ID_SERCOM0_CORE    0x0D
//#define GCLK_CLKCTRL_ID_SERCOM1_CORE    0x0E
//#define GCLK_CLKCTRL_ID_SERCOM2_CORE    0x0F
//#define GCLK_CLKCTRL_ID_SERCOM3_CORE    0x10
//#define GCLK_CLKCTRL_ID_TC0_TC1         0x13
//
//#define GCLK_CLKCTRL_CLKEN          BIT(14)

#define CLKCTRL_GEN_Pos        8            /* Generic Clock Generator */
#define CLKCTRL_GEN_Msk        ((0xF) << CLKCTRL_GEN_Pos)
#define CLKCTRL_GEN(value)     (CLKCTRL_GEN_Msk & ((value) << CLKCTRL_GEN_Pos))
#define CLKCTRL_GEN_GCLK0_Val   (0x0)   /**< \brief (GCLK_CLKCTRL) Generic clock generator 0 */
#define TC0_CLKCTRL_CLKEN_POS               14           /*Clock Enable */
#define TC0_CLKCTRL_CLKEN                   ((0x1) << TC0_CLKCTRL_CLKEN_POS)
#define TC0_CLKCTRL_GEN_POS                 8
#define TC0_CLKCTRL_GEN                 ((0x0) << TC0_CLKCTRL_GEN_POS)

#define CLKCTRL_CLKEN_Pos               14           /*Clock Enable */
#define CLKCTRL_CLKEN                   ((0x1) << CLKCTRL_CLKEN_Pos)

#define CLKCTRL_ID_Pos         0          /* Generic Clock Selection ID */
#define CLKCTRL_ID_Msk         ((0x3F) << CLKCTRL_ID_Pos)
#define CLKCTRL_ID(value)      (CLKCTRL_ID_Msk & ((value) << CLKCTRL_ID_Pos))

/***************PM Registers***************************/
#define PM_CTRL_REG                 PM_REGBASE
#define PM_APBCMASK_REG             PM_REGBASE + 0x20

#define PM_APBCMASK_SERC0M0         BIT(2)
#define PM_APBCMASK_SERC0M1         BIT(3)
#define PM_APBCMASK_SERC0M2         BIT(4)
#define PM_APBCMASK_SERC0M3         BIT(5)
//#define PM_APBCMASK_TC0             BIT(8)


/****************SERCOM Selection**********************/

#define SERCOM_SEL_OFFSET	             0x400       /*  SERCOM selection offset*/
#define SERCOM_CTRL_REGBASE(SercomSel)   SERCOM_REGBASE +(SercomSel * SERCOM_SEL_OFFSET) 



#endif 