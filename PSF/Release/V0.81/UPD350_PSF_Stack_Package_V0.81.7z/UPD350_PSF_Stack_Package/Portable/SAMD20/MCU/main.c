
#include <hal_atomic.h>
#include <hpl_init.h>
#include <stdinc.h>
#include <Interrupts.h>


int main()
{
   
    MCU_Init();

    (void)PSF_Init();
    
    while(TRUE)
    {   
        PSF_RUN();
        
    }

    return TRUE;
}
