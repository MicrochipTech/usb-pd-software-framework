/*******************************************************************************
Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#ifndef _DEBUG_H_
#define _DEBUG_H_


#ifdef CONFIG_HOOK_DEBUG_MSG

    #define HOOK_DEBUG_PORT_STR(_portNum_,_str_)                   {CONFIG_HOOK_DEBUG_INT32(_portNum_);\
                                                                    CONFIG_HOOK_DEBUG_STRING(_str_);}

    #define HOOK_DEBUG_BUF_UINT8(_prtNum_,_str1_,_u8Buf_,_u32Len_,_str2_)  {CONFIG_HOOK_DEBUG_INT32(_prtNum_);\
                                                                            CONFIG_HOOK_DEBUG_STRING(_str1_);\
                                                                            HookDebugBufferUint8(_u8Buf_,_u32Len_);\
                                                                            CONFIG_HOOK_DEBUG_STRING(_str2_);}

    #define HOOK_DEBUG_BUF_UINT16(_prtNum_,_str1_,_u16Buf_,_u32Len_,_str2_)  {CONFIG_HOOK_DEBUG_INT32(_prtNum_);\
                                                                             CONFIG_HOOK_DEBUG_STRING(_str1_);\
                                                                            HookDebugBufferUint16(_u16Buf_,_u32Len_);\
                                                                            CONFIG_HOOK_DEBUG_STRING(_str2_);}

    #define HOOK_DEBUG_BUF_UINT32(_prtNum_,_str1_,_u32Buf_,_u32Len_,_str2_)  {CONFIG_HOOK_DEBUG_INT32(_prtNum_);\
                                                                     CONFIG_HOOK_DEBUG_STRING(_str1_);\
                                                                    HookDebugBufferUint32(_u32Buf_,_u32Len_);\
                                                                    CONFIG_HOOK_DEBUG_STRING(_str2_);}

    #define HOOK_DEBUG_BUF_INT32(_prtNum_,_str1_,_i32Buf_,_u32Len_,_str2_)  {CONFIG_HOOK_DEBUG_INT32(_prtNum_);\
                                                                     CONFIG_HOOK_DEBUG_STRING(_str1_);\
                                                                    HookDebugBufferInt32(_i32Buf_,_u32Len_);\
                                                                    CONFIG_HOOK_DEBUG_STRING(_str2_);}

    void HookDebugBufferInt32 (INT32 *pi32Buffer, UINT32 u32TotalCount);
	void HookDebugBufferUint32 (UINT32 *pu32Buffer, UINT32 u32TotalCount);
	void HookDebugBufferUint16 (UINT16 *pu16Buffer, UINT32 u32TotalCount);
	void HookDebugBufferUint8 (UINT8 *pu8Buffer, UINT32 u32TotalCount);

#else

    #define HOOK_DEBUG_PORT_STR(_portNum_,_str_) 

    #define HOOK_DEBUG_BUF_UINT8(_prtNum_,_str1_,_u8Buf_,_u32Len_,_str2_)  

    #define HOOK_DEBUG_BUF_UINT16(_prtNum_,_str1_,_u16Buf_,_u32Len_,_str2_) 

    #define HOOK_DEBUG_BUF_UINT32(_prtNum_,_str1_,_u32Buf_,_u32Len_,_str2_)

    #define HOOK_DEBUG_BUF_INT8(_prtNum_,_str1_,_i8Buf_,_u32Len_,_str2_) 

#endif

#endif
