/*******************************************************************************
Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#ifndef _INT_GLOBALS_H_
#define _INT_GLOBALS_H_


extern DEVICE_POLICY_MANAGER gasDPM[CONFIG_PD_PORT_COUNT];

extern PolicyEngine_Status gasPolicy_Engine[CONFIG_PD_PORT_COUNT];

extern TYPEC_CONTROL  gasTypeCcontrol[CONFIG_PD_PORT_COUNT];

extern PORT_CONFIG_DATA gasPortConfigurationData[CONFIG_PD_PORT_COUNT];

extern UPD_PIO_CONFIG_DATA const gasUpdPioConfigData[CONFIG_PD_PORT_COUNT];

extern PROTOCOL_LAYER_STRUCT gasPRL [CONFIG_PD_PORT_COUNT];

extern PRL_RECVBUFF gasPRLRecvBuff [CONFIG_PD_PORT_COUNT];

#ifdef INCLUDE_PD_3_0

extern PRL_EXTMSG_BUFF gasExtendedMsgBuff [CONFIG_PD_PORT_COUNT];

extern PRL_CHUNK_STRUCT gasChunkSM [CONFIG_PD_PORT_COUNT];

#endif 

extern PDTIMER gasPDTimers[MAX_CONCURRENT_TIMERS];

extern UINT8 gau8PortDisable [CONFIG_PD_PORT_COUNT];


#if INCLUDE_POWER_MANAGEMENT_CTRL
extern UINT8 gau8ISRPortState [CONFIG_PD_PORT_COUNT];

extern UINT8 gau8PortIdleTimerID [CONFIG_PD_PORT_COUNT];

extern UINT8 gu8SetMCUidle;
#endif

#if (FALSE != INCLUDE_PDFU)    
    extern UINT8 gu8PDFUResBuffer[260];
#endif
    
//Functions


UINT8 PD_SPIRegresTest();

void WaitUntilSPITestRegister(UINT8 u8PortNum);

void PD_InitializeInternalGlobals();

#endif