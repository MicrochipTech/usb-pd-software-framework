
/*******************************************************************************
  Zeus stack configuration

  Company:
    Microchip Technology Inc.

  File Name:
    PSFPort.h

  Summary:
    Zeus stack configuration header file 

  Description:
    This header file contains the configuration parameters of zeus stack to configures the Power delivery modules
*******************************************************************************/
//DOM-IGNORE-BEGIN
/*******************************************************************************

Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

********************************************************************************

*******************************************************************************/
#ifndef _PSF_PORT_H_
#define _PSF_PORT_H_

//DOM-IGNORE-END

#include "PSF_Config.h"
#include "../../Portable/SAMD20/Peripherals/Timers/Timers.h"
#include "../../Portable/SAMD20/Peripherals/SPI/SERCOM_Spi.h"
#include "../../Portable/SAMD20/Peripherals/GPIO/GPIO.h"
#include "../../Portable/SAMD20/MCU/Interrupts.h"
// *****************************************************************************
// *****************************************************************************
// Section: HOOK CONFIGURATION
// *****************************************************************************
// *****************************************************************************
/* TBD Notify message reception*/
/***********************************************************************************************************
  Function:
              CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
  Summary:
    This function is called before entering into the policy engine state
    machine
  Description:
    This function is called at the entry of PE_RunStateMachine() API before
    executing the policy engine state machine.New PD message received by
    the protocol layer is passed as argument in this function before
    processing it in the policy engine state machine.USER_APPLICATION can
    define this function if a change in default policy engine state machine
    behaviour is needed. Define relevant function that has one UINT8
    argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
    _u8DataBuf_ -   Pointer to a byte buffer containing PD message.
    _u8SOPType_ -   Sop Type of the message
    _u32Header_ -   32 bit header passed of which lower word is PD message
                    header and higher word is extended message header if
                    passed message is extended message.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(_u8Port_Num_, _u8DataBuf_\\
    ,_u8SOPType_,_u32Header_)\\
    HookPolicyEnginePreProcess(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
    
    void HookPolicyEnginePreProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header);
    
    void HookPolicyEnginePreProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
    {
    
        //any application related change or enhancement for the PE_RunStateMachine() API
    
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                                                       
  ***********************************************************************************************************/

#define CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)   


/*TODO: to be removed*/
/************************************************************************************************************
  Function:
          CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
    
  Summary:
    This function is called before exiting from the policy engine state
    machine
  Description:
    This function is called at the exit of PE_RunStateMachine() API after
    executing the policy engine state machine. USER_APPLICATION can define
    this function if a change in default policy engine state machine
    behaviour is needed. Define relevant function that has one UINT8
    argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
    _u8DataBuf_ -   Pointer to a byte buffer containig PD message to be send
    _u8SOPType_ -   Sop Type of the message to be send
    _u32Header_ -   32 bit header of the PD message to be send.Lower word is
                    PD message header and higher word is extended message
                    header if passed message is extended message.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS(_u8Port_Num_, _u8DataBuf_, \\
    _u8SOPType_,_u32Header_) \\
    HookPolicyEnginePostProcess(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
    
    void HookPolicyEnginePostProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header);
    
    void HookPolicyEnginePostProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
    {
    
    //any application related change or enhancement for the PE_RunStateMachine() API

    }
    </code>
  Remarks:
    User definition of this Hook function is optional                                                        
  ************************************************************************************************************/
#define CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_) 			

/**************************************************************************
  Function:
            CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_)
  Summary:
    This function is called before entering into the DPM state machine
  Description:
    This function is called at the entry of DPM_StateMachine() API before
    executing the Type C state machine and policy engine state machine.
    USER_APPLICATION can define this function if a change is required in
    default device policy manager functionality. Define relevant function
    that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_) \\
                    HookDevicePolicyManagerPreProcess(_u8port_num_)
    
    void HookDevicePolicyManagerPreProcess(UINT8 u8PortNum);
    
    void HookDevicePolicyManagerPreProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the
        //DPM_StateMachine() API
    
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                      
  **************************************************************************/

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_)     

/*************************************************************************************
  Function:
            CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(_u8port_num_)
  Summary:
    This function is called before exiting from the DPM state machine
  Description:
    This function is called at the exit of DPM_StateMachine() API after
    executing the Type C state machine and policy engine state machine.
    USER_APPLICATION can define this function if a change is required in
    default device policy manager functionality. Define relevant function
    that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(_u8port_num_) \\
                          HookDevicePolicyManagerPostProcess(_u8port_num_)
    
    void HookDevicePolicyManagerPostProcess(UINT8 u8PortNum);
    
    void HookDevicePolicyManagerPostProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the DPM_StateMachine() API
    
    }
    </code>

  Remarks:
    User definition of this Hook function is optional                                 
  *************************************************************************************/
#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(_u8port_num_) 	


/*TODO: Remove it */
/******************************************************************************************
  Function:
          CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS(_u8port_num_)
    
  Summary:
    This function is called before entering into the Type C state machine
  Description:
    This function is called at the entry of TypeC_RunStateMachine() API
    before executing the TypeC state machine. USER_APPLICATION can define
    this function if a change in default Type C state machine behaviour is
    needed. Define relevant function that has one UINT8 argument without
    \return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS(_u8port_num_)   \\
     HookTypeCManagementPreProcess(_u8port_num_)
    
    void HookTypeCManagementPreProcess(UINT8 u8PortNum);
    
    void HookTypeCManagementPreProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the TypeC_RunStateMachine() API
    
    }
    </code>
  Remarks:
    None                                                                                   
  ******************************************************************************************/
#define CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS(_u8port_num_)		

/******************************************************************************************
  Function:
          CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS(_u8port_num_)
    
  Summary:
    This function is called before exiting from the Type C state machine
  Description:
    This function is called at the exit of TypeC_RunStateMachine() API
    after executing the TypeC state machine. USER_APPLICATION can define
    this function if a change in default TypeC state machine behaviour is
    needed. Define relevant function that has one UINT8 argument without
    \return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS(_u8port_num_)   \\
    HookTypeCManagementPostProcess(_u8port_num_)
    
    void HookTypeCManagementPostProcess(UINT8 u8PortNum);
    
    void HookTypeCManagementPostProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the TypeC_RunStateMachine() API
    
    }
    </code>
  Remarks:
    None                                                                                   
  ******************************************************************************************/
#define CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS(_u8port_num_)

/********************************************************************************************************************************************
  Function:
              CONFIG_HOOK_PRL_TX_MSG_PRE_PROCESS(_u8port_num_, _u8sop_type_, _u32header_, _pu8databuff_, _pfntxcallback_, _u32PkdPEstOn_TxStatus_)
    
  Summary:
    This function is called before processing the transmit message data
    from policy engine in protocol layer
  Description:
    This function is called at the entry of PRL_Tranmsit() API before
    processing the Message from Policy Engine. It has all the arguments
    passed to the API PRL_Transmit() by policy engine It is a placeholder
    for USER_APPLICATION to enhance the API.Define relevant function that
    has UINT8,UINT8,UINT32,UINT8 * ,PRLTxCallback and UINT32 arguments
    without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -                         Port number of the device. Value
                                           passed will be less than
                                           CONFIG_PD_PORT_COUNT
    _u8sop_type_ -                          Sop Type of the message
    _u32header_ -                           32 bit header passed of which
                                           lower word is PD message header &amp;
                                           higher word is extended message
                                           header if passed message is
                                           extended message.
    _pu8databuff_ -                         pointer to a byte buffer
                                           containig PD message
    _pfntxcallback_ -                       Pointer to callback function of
                                           type PRLTxCallback
    _u32PkdPEstOn_TxStatus_ -               argument to Tx callback function<p />
    Prototype of PRLTxCallback function -  void (*PRLTxCallback)(UINT8
                                           u8PortNum, UINT8 u8TxDonePEst,
                                           UINT8 u8TxDonePESubst, UINT8
                                           u8TxFailedPEst, UINT8
                                           u8TxFailedPESubst);
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_TX_MSG_PRE_PROCESS(_u8port_num_, _u8sop_type_, _u32header_,\\
       _pu8databuff_,_pfntxcallback_, _u32PkdPEstOn_TxStatus_) \\
        HookPRLTxMsgPreProcess(_u8port_num_, _u8sop_type_, _u32header_, _pu8databuff_,\\
        _pfntxcallback_,_u32PkdPEstOn_TxStatus_)
    
        void HookPRLTxMsgPreProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus);
    
        void HookPRLTxMsgPreProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus)
        {
            //any application related change or enhancement for the PRL_Tranmsit() API

        }
    
    </code>
  Remarks:
    None                                                                                                                                     
  ********************************************************************************************************************************************/
#define CONFIG_HOOK_PRL_TX_MSG_PRE_PROCESS(_u8port_num_, _u8sop_type_, _u32header_, _pu8databuff_, _pfntxcallback_, _u32PkdPEstOn_TxStatus_)

/*****************************************************************************************************************************************
  Function:
          CONFIG_HOOK_PRL_TX_MSG_POST_PROCESS(_u8port_num_, _u8sop_type_, _u32header_, _pu8databuff_, _pfntxcallback_, _u32PkdPEstOn_TxStatus_)
    
  Summary:
    This function is called after processing the transmit message data from
    policy engine to UPD350 FIFO format
  Description:
    This function is called in PRL_Tranmsit() API after processing the
    message from Policy Engine into UPD350 FIFO format.Exactly,After
    filling the UPD350's TX_FIFO. It has all the arguments passed to the
    API PRL_Transmit() by policy engine It is a placeholder for
    USER_APPLICATION to enhance the API.Define relevant function that has
    UINT8,UINT8,UINT32,UINT8 * ,PRLTxCallback and UINT32 arguments without
    \return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -                         Port number of the device. Value
                                           passed will be less than
                                           CONFIG_PD_PORT_COUNT
    _u8sop_type_ -                          Sop Type of the message
    _u32header_ -                           32 bit header passed of which
                                           lower word is PD message header &amp;
                                           higher word is extended message
                                           header if passed message is
                                           extended message.
    _pu8databuff_ -                         pointer to a byte buffer
                                           containig PD message
    _pfntxcallback_ -                       Pointer to callback function of
                                           type PRLTxCallback
    _u32PkdPEstOn_TxStatus_ -               argument to Tx callback function<p />
    Prototype of PRLTxCallback function -  void (*PRLTxCallback)(UINT8
                                           u8PortNum, UINT8 u8TxDonePEst,
                                           UINT8 u8TxDonePESubst, UINT8
                                           u8TxFailedPEst, UINT8
                                           u8TxFailedPESubst);
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_TX_MSG_POST_PROCESS(_u8port_num_, _u8sop_type_, _u32header_,\\
        _pu8databuff_,pfntxcallback_, _u32PkdPEstOn_TxStatus_)\\
        HookPRLTxMsgPostProcess(_u8port_num_, _u8sop_type_, _u32header_,\\
        _pu8databuff_, _pfntxcallback_, _u32PkdPEstOn_TxStatus_)
    
        void HookPRLTxMsgPostProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus);
    
        void HookPRLTxMsgPostProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus)
        {
            //any application related change or enhancement for the PRL_Tranmsit() API
        }
    
    </code>
  Remarks:
    None                                                                                                                                  
  *****************************************************************************************************************************************/
#define CONFIG_HOOK_PRL_TX_MSG_POST_PROCESS(_u8port_num_, _u8sop_type_, _u32header_, _pu8databuff_, _pfntxcallback_, _u32PkdPEstOn_TxStatus_)

/**************************************************************************************
  Function:
          \#define CONFIG_HOOK_PRL_RX_MSG_PRE_PROCESS(_u8port_num_)
    
  Summary:
    This function is called before receiving the message from UPD350's
    RX_FIFO
  Description:
    The function is called at the entry of PRL_ReceiveMsg() API.It is a
    placeholder for USER_APPLICATION to enhance the API. Define relevant
    \function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_RX_MSG_PRE_PROCESS(_u8port_num_)     \\
        HookPRLRxMsgPreProcess(_u8port_num_)
    
       void HookPRLRxMsgPreProcess(UINT8 u8Portnum);
    
       void HookPRLRxMsgPreProcess(UINT8 u8Portnum)
        {
            //any application related change or enhancement for the  PRL_ReceiveMsg API
        }
    
    </code>
  Remarks:
    None                                                                               
  **************************************************************************************/

//TODO: Revisit*/
#define CONFIG_HOOK_PRL_RX_MSG_PRE_PROCESS(_u8port_num_)

/**********************************************************************************
  Function:
          \#define CONFIG_HOOK_PRL_RX_MSG_POST_PROCESS(_u8port_num_)
    
  Summary:
    This function is called after receiving and processing the message from
    UPD350's RX_FIFO
  Description:
    The function is called at the exit of PRL_ReceiveMsg() API. It is a
    placeholder for USER_APPLICATION to enhance the API. Define relevant
    \function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_PRL_RX_MSG_POST_PROCESS(_u8port_num_)   \\
    HookPRLRxMsgPostProcess(_u8port_num_)
    
    void HookPRLRxMsgPostProcess(UINT8 u8Portnum);
    
    void HookPRLRxMsgPostProcess(UINT8 u8Portnum)
    {
    
        //any application related change or enhancement for the  PRL_ReceiveMsg API
    
    }
    
    </code>
  Remarks:
    None                                                                           
  **********************************************************************************/
#define CONFIG_HOOK_PRL_RX_MSG_POST_PROCESS(_u8port_num_)

/************************************************************************************************
  Function:
          \#define CONFIG_HOOK_PRL_CHUNK_SM(_u8port_num_)
    
  Summary:
    This function is called before running the chunk state machine
  Description:
    The function is called at the entry of PRL_RunChunkStateMachine() API.
    It is a placeholder for USER_APPLICATION to enhance the API. Define
    relevant function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_CHUNK_SM(_u8port_num_)  \\
        HookPRLChunkSM(_u8port_num_)
    
        void HookPRLChunkSM(UINT8 u8Portnum);
    
        void HookPRLChunkSM(UINT8 u8Portnum)
        {
            // any application related change or enhancement for the PRL_RunChunkStateMachine API
        }
    
    </code>
  Remarks:
    None                                                                                         
  ************************************************************************************************/
#define CONFIG_HOOK_PRL_CHUNK_SM(_u8port_num_)

/************************************************************************************
  Function:
          \#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT(_u8port_num_)
    
  Summary:
    This function is called before processing the UPD alert interrupt
  Description:
    The function is called at the entry of UPDIntr_AlertHandler() API. It
    is a placeholder for USER_APPLICATION to enhance the API. Define
    relevant function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT(_u8port_num_)    \\
    HookUPDAlertISRAllPort(_u8port_num_)
    
    void HookUPDAlertISRAllPort(UINT8 u8Portnum);
    
    void HookUPDAlertISRAllPort(UINT8 u8Portnum)
    {
        // any application related change or enhancement for UPDIntr_AlertHandler API
    }
    
    </code>
  Remarks:
    None                                                                             
  ************************************************************************************/
#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT(_u8port_num_)				

/****************************************************************************************************
  Function:
                \#define CONFIG_HOOK_NOTIFY_PD_EVENTS_CB(_u8port_num_, _u8pd_event_)
    
  Summary:
    Notifies the USER_APPLICATION about various PD events such as Type C
    Attach and Detach , Type C orientation .
  Description:
    This function is called by the various modules of Zeus Stack to notify
    the USER_APPLICATION about different PD events such as Type-C Attach
    and Detach , Type-C Orientation. USER_APPLICATION can define this hook
    \function if it wants external handling of the PD events. Define
    relevant function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
    _u8pd_event_ -   Type of PD event occurred inside the stack. This
                    argument can take one of the following,<p />TYPEC_ATTACH_EVENT
                    \- Attach event is detected in Type C State<p />machine<p />TYPEC_DETACH_EVENT
                    \- Detach event is detected in Type C State<p />machine<p />TYPEC_CC1_ORIENTATION
                    \- Attach is detected in CC1 pin<p />TYPEC_CC2_ORIENTATION
                    \- Attach is detected in CC2 pin
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_NOTIFY_PD_EVENTS_CB(_u8port_num_, _u8pd_event_) \\
    HookNotifyPDEvents(_u8port_num_, _u8pd_event_)
    
    void HookNotifyPDEvents(UINT8 u8Portnum, UINT8 u8PDEvents);
    
    void HookNotifyPDEvents(UINT8 u8Portnum, UINT8 u8PDEvents)
    {
    
         Switch(u8PDEvents)
        {
            case TYPEC_ATTACH_EVENT:
            {
                //USER_APPLICATION code for Type C attach event in "u8PortNum" Port
                break;
    
            }
            case TYPEC_DETACH_EVENT:
            {
                //USER_APPLICATION code for Type C detach event in "u8PortNum" Port
                break;
    
            }
            case TYPEC_CC1_ORIENTATION:
            {
                //USER_APPLICATION code for Type C attach event in CC1 of "u8PortNum" Port
                break;
    
            }
            case TYPEC_CC2_ORIENTATION:
            {
                //USER_APPLICATION code for Type C attach event in CC2 of "u8PortNum" Port
                break;
    
            }
            default:
            {
                break;
            }
    
        }
    
    }
    
    </code>
  Remarks:
    User definition of this Hook function is optional                                                
  ****************************************************************************************************/
#define CONFIG_HOOK_NOTIFY_PD_EVENTS_CB(_u8port_num_, _u8pd_event_)    PDStack_Events(_u8port_num_, _u8pd_event_)

#define TYPEC_ATTACH_EVENT                  0
#define TYPEC_DETACH_EVENT                  1
#define TYPEC_CC1_ORIENTATION               2
#define TYPEC_CC2_ORIENTATION               3
#define TYPEC_ATTACHED_SRC_DRIVE_PWR_EVENT  4
#define TYPEC_SNK_CURRENT_LIMIT_EVENT       5

/**************************************************************************************************
	Function:
		CONFIG_HOOK_UPDATE_CFG_GLOBALS(_CfgGlobals_)

	Summary :
		Updates the configuration parameters of stack at run time

	Description :
		This function is called to update the configuration parameters at run time during initialization of the stack. 
		This API must have a prototype of PORT_CONFIG_DATA as argument without any return type.
		
	Precondition :
		None.

	Parameters :
		_CfgGlobals_ - Holds the variable of the structure PORT_CONFIG_DATA

	Return :
		None.

	Example :

		<code>
		#define  CONFIG_HOOK_UPDATE_CFG_GLOBALS(_CfgGlobals_)            STRAPS_PowerRole_Set(_CfgGlobals_)

		void STRAPS_PowerRole_Set(PORT_CONFIG_DATA *PortConfigData);

		void STRAPS_PowerRole_Set(PORT_CONFIG_DATA *PortConfigData)
		{
			// Read Straps for enabled ports 1 to n
			
			if(gpio_get_pin_level(PA28) == PULL_UP)
			{
				// Configure Cfg variables for Source
				// Set Source Capabilities
			}
			
			else
			{
				// Configure Cfg variables for sink
				// Set Sink Capabilities
			}
			
			// Repeat the above steps upto port n

		}
		</code>

	Remarks:
		User definition of this Hook function is optional
**************************************************************************************************/
#define  CONFIG_HOOK_UPDATE_CFG_GLOBALS(CfgGlobals)  	

/**************************************************************************************************
	Function:
		CONFIG_HOOK_PORTS_ENABLE_DISABLE(_pu8PortsEnDis_,_pPortConfigData_)

	Summary :
		Update the port Enable/Disable parameters of stack at run time.

	Description :
		This function is called to update the port Enable/Disable parameters at run time during initialization of the stack
        and port Enable/Disable status can be read from this API.
        		
	Precondition :
		None.

	Parameters :
		PortsEnDis - Holds the array of port Enable/Disable variable
		_pPortConfigData_ - Holds the PORT_CONFIG_DATA data structure.

	Return :
		None.

	Example :

		<code>
		#define  CONFIG_HOOK_PORTS_ENABLE_DISABLE(_pu8PortsEnDis_,_pPortConfigData_)      Ports_EnableDisable(_pu8PortsEnDis_,_pPortConfigData_)

		void Ports_EnableDisable(UINT8 *u8PortEnDis, PORT_CONFIG_DATA *PortConfigData)

		void Ports_EnableDisable(UINT8 *u8PortEnDis, PORT_CONFIG_DATA *PortConfigData)
		{
			// if Port-0 to be enabled
            u8PortEnDis[0] = PORT_STATUS_ENABLED;

            // if Port-1 to be disabled
            u8PortEnDis[1] = PORT_STATUS_DISABLED;
			
			//any Source or sink based port configuration if required based on PortConfigData

		}
		</code>

	Remarks:
		User definition of this Hook function is optional
**************************************************************************************************/
#define  CONFIG_HOOK_PORTS_ENABLE_DISABLE(_pu8PortsEnDis_,_pPortConfigData_)       

// *****************************************************************************
// *****************************************************************************
// Section: DEBUG MESSAGES CONFIGURATION
// *****************************************************************************
// *****************************************************************************

#if CONFIG_HOOK_DEBUG_MSG
        /***********************************************************************
          Function:
                  \#define CONFIG_HOOK_DEBUG_INIT()
            
          Summary:
            Initialization of debug module
          Description:
            This function is called during
            initialization of stack if CONFIG_HOOK_DEBUG_MSG is set to 1. Define
            relevant function that has no arguments without return type.
          Conditions:
            None.
          Return:
            None.
          Example:
            <code>
                \#define CONFIG_HOOK_DEBUG_INIT()          uart_init()
            
                void uart_init();
            
                void uart_init()
                {
                    //Initialzes the uart module to send and receive a character
                }
            
            </code>
          Remarks:
            User definition of this Hook function is optional                   
          ***********************************************************************/  
	#define CONFIG_HOOK_DEBUG_INIT()				                            SERCOMUART_Init()
    /*************************************************************************
      Function:
              \#define CONFIG_HOOK_DEBUG_STRING(_str_)
        
      Summary:
        Initialization of debug module
      Description:
        This function is called by stack to send
        a character string to DEBUG_MODULE. This API will be called if
        CONFIG_HOOK_DEBUG_MSG is set to 1. Define relevant function that has
        CHAR pointer argument without return type.
      Conditions:
        None.
      Input:
        _str_ -  Pointer to the character buffer
      Return:
        None.
      Example:
        <code>
            \#define CONFIG_HOOK_DEBUG_STRING(_str_)       uart_write(_str_)
        
            void uart_write(char *chBuffer);
        
            void uart_write(char *chBuffer)
            {
                //Write character string to UART
            }
        
        </code>
      Remarks:
        User definition of this Hook function is optional                     
      *************************************************************************/ 
	#define CONFIG_HOOK_DEBUG_STRING(_str_)		                                  

    /************************************************************************
      Function:
              \#define CONFIG_HOOK_DEBUG_CHAR(_char_)
        
      Summary:
        Send CHAR to DEBUG_MODULE
      Description:
        This function is called by stack to send a character to DEBUG_MODULE.
        This API will be called if CONFIG_HOOK_DEBUG_MSG is set to 1. Define
        relevant function that has CHAR argument without return type.
      Conditions:
        None.
      Input:
        chName -  Character to be sent to DEBUG_MODULE
      Return:
        None.
      Example:
        <code>
            \#define CONFIG_HOOK_DEBUG_CHAR(_char_)   uart_write(_char_)
        
            void uart_write(char chName);
        
            void uart_write(char chName)
            {
                //Write character to UART
            }
        
        </code>
      Remarks:
        User definition of this Hook function is optional                    
      ************************************************************************/ 
	#define CONFIG_HOOK_DEBUG_CHAR(_char_)			                           	SERCOMUART_WriteChar(_char_)

    /**************************************************************************
      Function:
              \#define CONFIG_HOOK_DEBUG_UINT8(_u8Val_)
        
      Summary:
        Send UINT8 to DEBUG_MODULE
      Description:
        This function is called by stack to send a
        UINT8 data to DEBUG_MODULE This API will be called if
        CONFIG_HOOK_DEBUG_MSG is set to 1. Define relevant function that has
        UINT8 argument without return type.
      Conditions:
        None.
      Input:
        u8Val -  UINT8 data to be sent to DEBUG_MODULE
      Return:
        None.
      Example:
        <code>
            \#define CONFIG_HOOK_DEBUG_UINT8(_u8Val_)     uart_write(_u8Val_)
        
            void uart_write(UINT8 u8Val);
        
            void uart_write(UINT8 u8Val)
            {
                //Convert UINT8 to character string and write to UART
            }
        
        </code>
      Remarks:
        User definition of this Hook function is optional                      
      **************************************************************************/ 
	#define CONFIG_HOOK_DEBUG_UINT8(_u8Val_)		                            SERCOMUART_WriteUINT8(_u8Val_)

    /*************************************************************************
      Function:
              \#define CONFIG_HOOK_DEBUG_UINT16(_u16Val_)
        
      Summary:
        Send UINT16 to DEBUG_MODULE
      Description:
        This function is called by stack to send
        a UINT16 data to DEBUG_MODULE This API will be called if
        CONFIG_HOOK_DEBUG_MSG is set to 1. Define relevant function that has
        UINT16 argument without return type.
      Conditions:
        None.
      Input:
        u16Val -  UINT16 data to be sent to DEBUG_MODULE
      Return:
        None.
      Example:
        <code>
            \#define CONFIG_HOOK_DEBUG_UINT16(_u16Val_)     uart_write(_u16Val_)
        
            void uart_write(UINT16 u16Val);
        
            void uart_write(UINT16 u16Val)
            {
                //Convert UINT16 to character string and write to UART
            }
        
        </code>
      Remarks:
        User definition of this Hook function is optional                     
      *************************************************************************/ 
	#define CONFIG_HOOK_DEBUG_UINT16(_u16Val_)		                            SERCOMUART_WriteUINT16(_u16Val_)
    /*************************************************************************
      Function:
              \#define CONFIG_HOOK_DEBUG_UINT32(_u32Val_)
        
      Summary:
        Send UINT32 to DEBUG_MODULE
      Description:
        This function is called by stack to send
        a UINT32 data to DEBUG_MODULE. This API will be called if
        CONFIG_HOOK_DEBUG_MSG is set to 1. Define relevant function that has a
        UINT32 argument without return type.
      Conditions:
        None.
      Input:
        u32Val -  UINT32 data to be sent to DEBUG_MODULE
      Return:
        None.
      Example:
        <code>
            \#define CONFIG_HOOK_DEBUG_UINT32(_u32Val_)    uart_write(_u32Val_)
        
            void uart_write(UINT32 u32Val);
        
            void uart_write(UINT32 u32Val)
            {
                //Convert UINT32 to character string and write to UART
            }
        
        </code>
      Remarks:
        User definition of this Hook function is optional                     
      *************************************************************************/ 
	#define CONFIG_HOOK_DEBUG_UINT32(_u32Val_)		                            SERCOMUART_WriteUINT32(_u32Val_)

    /**************************************************************************
      Function:
                \#define CONFIG_HOOK_DEBUG_INT32(_i32Val_)
        
      Summary:
        Send INT32 to DEBUG_MODULE
      Description:
        This function is called by stack to send
        a INT32 data to DEBUG_MODULE. This API will be called if
        CONFIG_HOOK_DEBUG_MSG is set to 1. Define relevant function that has
        INT32 argument without return type.
      Conditions:
        None.
      Input:
        i32Val -  INT32 data to be sent to DEBUG_MODULE
      Return:
        None.
      Example:
        <code>
            \#define CONFIG_HOOK_DEBUG_UINT16(_i32Val_)        uart_write(_i32Val_)
        
            void uart_write(INT32 i32Val);
        
            void uart_write(INT32 i32Val)
            {
                //Convert INT32 to character string and write to UART
            }
        
        </code>
      Remarks:
        User definition of this Hook function is optional                      
      **************************************************************************/ 
    #define CONFIG_HOOK_DEBUG_INT32(_i32Val_)		                            SERCOMUART_WriteINT32(_i32Val_)
		                                
#else
	#define CONFIG_HOOK_DEBUG_INIT()				
	#define CONFIG_HOOK_DEBUG_STRING(_str_)		
	#define CONFIG_HOOK_DEBUG_CHAR(_char_)			
	#define CONFIG_HOOK_DEBUG_UINT8(_u8Val_)		
	#define CONFIG_HOOK_DEBUG_UINT16(_u16Val_)			
	#define CONFIG_HOOK_DEBUG_UINT32(_u32Val_)
    #define CONFIG_HOOK_DEBUG_INT32(_i32Val_)	
#endif



// *****************************************************************************
// *****************************************************************************
// Section: PDTimer configuration
// *****************************************************************************
// *****************************************************************************
/***********************************************************************
  Function:
            CONFIG_HOOK_HW_PDTIMER_INIT()
    
  Summary:
    Initializes and starts the hardware timer module.
  Description:
    This function initializes and starts the hardware timer module. Zeus
    Stack requires a single dedicated hardware timer module for its
    functionality. Define relevant function that has no argument without
    \return type.
  Conditions:
    None.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_HW_PDTIMER_INIT()       hw_timer_init()
    
    void hw_timer_init(void);
    
    void hw_timer_init(void)
    {
        //Initializes and starts the microcontroller timer module
    }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                  
  ***********************************************************************/			      
#define CONFIG_HOOK_HW_PDTIMER_INIT()	                Timer_Init()

/**************************************************************************************************
	Description :
	CONFIG_PDTIMER_INTERRUPT_RATE refers to the frequency of interrupt set in the hardware timer dedicated for zeus stack.In other words it is the resolution of the hardware timer.
	CONFIG_PDTIMER_INTERRUPT_RATE can be configured depending on the resolution of the hardware timer available

	Remarks :
	Resolution of the hardware timer has to be atleast 1ms.Tested resolution values of hardware timer are 500us,1ms(Corresponding CONFIG_PDTIMER_INTERRUPT_RATE values are 2000,1000)
	 
	Example :
	<code>
	# define CONFIG_PDTIMER_INTERRUPT_RATE 1000  (1000 interrupts per seconnd, with interrupt interval or resolution of 1ms)
	</code>
**************************************************************************************************/
#define CONFIG_PDTIMER_INTERRUPT_RATE	1000
/**************************************************************************************************
	Description :
	CONFIG_HOOK_SET_MCU_IDLE() is the function defined by the user to put the companion MCU into 
    idle mode when all the connected UPD350s are in idle mode.
 Context when it is called

	Remarks :
	None

	Example :
	<code>
	#define CONFIG_HOOK_SET_MCU_IDLE()	  SetMCUIdle()
	</code>
**************************************************************************************************/
#define CONFIG_HOOK_SET_MCU_IDLE()            SetMCUIdle()	

/**************************************************************************************************
	Description :
	CONFIG_HOOK_MCU_RESUME_FROM_IDLE() is the function defined by the user to wake up the companion MCU 
    from idle mode if interrupt is received from any of the connected UPD350s

	Remarks :
	None

	Example :
	<code>
	#define CONFIG_HOOK_MCU_RESUME_FROM_IDLE()	  MCUResumeFromIdle()
	</code>
**************************************************************************************************/
#define CONFIG_HOOK_MCU_RESUME_FROM_IDLE()    MCUResumeFromIdle()

/**************************************************************************************************
	Description :
	CONFIG_16_BIT_PDTIMEOUT can be defined as either 1 or 0 to set the timeout counter in PSF Stack to unsigned 16bit or unsigned 32bit correspondingly.
	When set as 1,maximum timeout that can be set will be 65535 ticks.(Ticks = Resolution of the Hardware timer used). When set as 0 , maximum timeout that can be set will be 4294967296 ticks.
	Default value of CONFIG_16_BIT_PDTIMEOUT is set as 1. With Hardware timer resolution set as 1ms , PSF stack will be capable of handling timeouts upto 65.535 Seconds.

	Remarks :
	None

	Example :
	<code>
	#define CONFIG_16_BIT_PDTIMEOUT	1 (Sets timeout variable inside the PDStack unsigned 16bit)
	#define CONFIG_16_BIT_PDTIMEOUT	0 (Sets timeout variable inside the PDStack unsigned 32bit)
	</code>
**************************************************************************************************/
#define CONFIG_16_BIT_PDTIMEOUT     1

// *****************************************************************************
// *****************************************************************************
// Section: Port power control configuration
// *****************************************************************************
// *****************************************************************************



/*Defines to be used for variable in u8EnaDisVBUSDIS PWRCTRL_SetVBUSDischarge API */
#define PWRCTRL_ENABLE_VBUSDIS      1
#define PWRCTRL_DISABLE_VBUSDIS     0
    

/*****************************************************************************
  Function:
          CONFIG_HOOK_HW_PORTPWR_INIT(_u8Port_Num_)
  Summary:
    Initializes all the hardware modules related to port power
    functionality
  Description:
    This function initializes the hardware modules related to port power
    functionality. Implementation of this function depends on the type of
    DC-DC Converter used. Port power(VBUS) of all ports must be set to 0V
    in this API. Define relevant function that has no argument without
    \return type.
  Conditions:
    None.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_HW_PORTPWR_INIT(_u8Port_Num_)       hw_portpower_init(_u8Port_Num_)
    
    void hw_portpower_init(void);
    
    void hw_portpower_init(void)
    {
        //Initializes the hardware modules related to port power functionality
    }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                        
  *****************************************************************************/
#define CONFIG_HOOK_HW_PORTPWR_INIT(_u8Port_Num_)                        PWRCTRL_initialization(_u8Port_Num_)

/****************************************************************************
  Function:
              CONFIG_HOOK_PORTPWR_DRIVE_VBUS(_u8Port_Num_, _u16VBUSVolatge_,_u16Current_)
    
  Summary:
    Drives the VBUS line of a given Type C port to a particular voltage
  Description:
    This function is used to drive the VBUS line of a given Type C port to
    a particular voltage.Implementation of this function depends on the
    type of DC-DC Converter used. Define relevant function that has
    UINT8,UINT8 arguments without return type.
  Conditions:
    None.
  Input:
    _u8Port_Num_ -     Port number of the device. Value passed will be less
                       than CONFIG_PD_PORT_COUNT
    _u16VBUSVolatge_ -  VBUS Voltage level to be driven. Data type of this
                       parameter must be UINT16. 
 * _u16Current_     - VBUS current level in mA.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_PORTPWR_DRIVE_VBUS(_u8Port_Num_, _u8VBUSVolatge_) \\
                      hw_portpower_driveVBUS(_u8Port_Num_, _u8VBUSVolatge_)
    
    void hw_portpower_driveVBUS(UINT8 u8PortNum,UINT8 u8VBUS_Volatge);
    
    void hw_portpower_driveVBUS(UINT8 u8PortNum,UINT8 u8VBUS_Volatge)
    {
    
        Switch(u8VBUS_Volatge)
        {
            case PWRCTRL_VBUS_0V:
            {
                //Drive 0V in VBUS line of "u8PortNum" Port
                break;
    
            }
            case PWRCTRL_VBUS_5V:
            {
                //Drive 5V in VBUS line of "u8PortNum" Port
                break;
    
            }
            case PWRCTRL_VBUS_9V:
            {
                //Drive 9V in VBUS line of "u8PortNum" Port
                break;
    
            }
            case PWRCTRL_VBUS_15V:
            {
                //Drive 15V in VBUS line of "u8PortNum" Port
                break;
    
            }
            case PWRCTRL_VBUS_20V:
            {
                //Drive 20V in VBUS line of "u8PortNum" Port
                break;
    
            }
            default:
            {
                break;
            }
    
        }
    
    
    }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                       
  ****************************************************************************/
#define CONFIG_HOOK_PORTPWR_DRIVE_VBUS(_u8Port_Num_,_u8PDOIndex_,_u16VBUSVolatge_,_u16Current_)	PWRCTRL_SetPortPower (_u8Port_Num_,_u8PDOIndex_,_u16VBUSVolatge_,_u16Current_)

/*******************************************************************************************
  Function:
                CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE( _u8Port_Num_,_u8EnableDisable_)
    
  Summary:
    Enables or disables VBUS Discharge functionality for a given Port
  Description:
    This function is used to enable or disable the VBUS Discharge
    functionality for a given Port .Implementation of this function depends
    on the type of DC-DC Converter used. Define relevant function that has
    UINT8,UINT8 arguments without return type.
  Conditions:
   CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE is called in ISR handler.
    This function must be very short, otherwise response time to the interrupt
    will take longer time.
  Input:
    _u8Port_Num_ -       Port number of the device. Value passed will be
                         less than CONFIG_PD_PORT_COUNT
    _u8EnableDisable_ -  Flag indicating whether to enable/disable VBUS
                         Discharge. Data type of this parameter must be
                         UINT8.<p />Value of this argument must be one of
                         the following,<p />PWRCTRL_ENABLE_VBUSDIS \- Enable
                         the VBUS Discharge for a given port<p />PWRCTRL_DISABLE_VBUSDIS
                         \- Disable the VBUS Discharge for a given port
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE(_u8Port_Num, _u8EnableDisable)   \\
                          hw_portpower_enab_dis_VBUSDischarge(_u8Port_Num, _u8EnableDisable)
    
    void hw_portpower_enab_dis_VBUSDischarge(UINT8 u8PortNum,UINT8 u8EnableDisable);
    
    void hw_portpower_enab_dis_VBUSDischarge(UINT8 u8PortNum,UINT8 u8EnableDisable)
    {
         Switch(u8EnableDisable)
        {
            case PWRCTRL_ENABLE_VBUSDIS:
            {
                //Enable the VBUS Discharge for "u8PortNum" Port
                break;
    
            }
            case PWRCTRL_DISABLE_VBUSDIS:
            {
                //Disable the VBUS Discharge for "u8PortNum" Port
                break;
    
            }
            default:
            {
                break;
            }
        }
    
    
    }
    </code>

  Remarks:
    User definition of this Hook function is mandatory.Passing of the Compliance test "TD.4.2.1" (Source Connect Sink) in "USB_Type_C_Functional_Test_Specification" depends on the VBUS Discharge circuitry used.
	Typical VBUS Discharge time from any higher voltage to 0V is around 10ms                                  
  *******************************************************************************************/
#define CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE(_u8Port_Num, _u8EnableDisable_)            PWRCTRL_ConfigVBUSDischarge(_u8Port_Num, _u8EnableDisable_)	

/*******************************************************************************************
  Function:
	CONFIG_HOOK_PORTPWR_ENABDIS_SINK_HW(_u8Port_Num, _u16Voltage_, _u16Current_)

  Summary:
	Enables or disables sink hardware circuitry to sinks the VBUS voltage for a given Port 
   based on the sink requested voltage and current.
   
  Description:
	  This function is used to enable or disable sink hardware circuitry which sinks the 
	  VBUS voltage for a given Port and also configure the Sink HW or circuitry 
      to Sink requested current and voltage.Implementation of this function depends
	  on the type of Sink circuitry used. 
   
  Conditions:
	None.
  Input:
	_u8Port_Num_ -       Port number of the device. Value passed will be
					     less than CONFIG_PD_PORT_COUNT
	_u16voltage_ -      Enable Sink HW Circuitry if the u16voltage is non Vsafe0V to drain power.
                        Disable sink HW circuitry if the u16voltage is VSafe0V.
                        Configure the HW to requested voltage passed in mV.
    _u16Current_ - Configure the HW  for the requested current passed in mA
  Return:
	None.
  Example:
	  <code>
		  \#define CONFIG_HOOK_PORTPWR_ENABDIS_SINK_HW(_u8Port_Num, _u16voltage_, _u16Current_)  \\
		  hw_SinkCircuitary_enab_dis_(_u8Port_Num, _u16voltage_, _u16Current_)

		void hw_SinkCircuitary_enab_dis_(UINT8 u8PortNum,UINT16 u16Votlage, UINT16 u16Current);

		void hw_SinkCircuitary_enab_dis_(UINT8 u8PortNum, UINT16 u16Votlage, UINT16 u16Current)
		{
   
            if (u16Current >= 3000)
			{
				//Configure the sink HW to 3A
			}
			else if (u16Current >= 1500)
			{
				//Configure the sink HW to 1.5A
			}
			else if (u16Current == 0)
			{
				//Configure the Sink HW to OFF state
			}
			else
			{
				// handle less than 1.5A configuration
			}
            
            if(u16Voltage == Vsafe0V)
            {
                //Disable the Sink circuitary for "u8PortNum" Port
            }
            else
            {
                //Enable the Sink circuitary for "u8PortNum" Port
             }
			
		}

	  </code>

  Remarks:
	  User definition of this Hook function is mandatory.
  *******************************************************************************************/
#define CONFIG_HOOK_PORTPWR_ENABDIS_SINK_HW(_u8Port_Num,_u16Voltage_,_u16Current_)
                                                                                           

/*********************************************************************************
  Function:
                CONFIG_HOOK_PIO_HANDLER_ISR(_u8PortNum_, _u16PIOsts_)
  Summary:
    ISR handler for PIO interrupt
  Description:
    This function is hook in the PIO ISR handler.

  Conditions:
    The Hook is called inside a ISR handler. Its definition should not enable or 
    disable interrupt or clear the PIO Status caused the interrupt.

 Input:
    _u8Port_Num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
    _u16PIOsts_ - Pio Interrupt Staus caused the PIO interrupt.

  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PIO_HANDLER_ISR(_u8PortNum_, _u16PIOsts_)()   

        void PIO_Handler(UINT8 u8PortNum, UINT16 u16PIOStatus);

        void PIO_Handler(UINT8 u8PortNum, UINT16 u16PIOStatus)
        {
            // PIO interrupt related handling
        }

    </code>
  Remarks:
    User definition of this Hook function is optional.
  *********************************************************************************/

								  
#define CONFIG_HOOK_PIO_HANDLER_ISR(_u8PortNum_, _u16PIOsts_)
                                              

/* Debounce configured for PRT_CTL/OCS */                                             
#define CONFIG_OCS_DEBOUNCE_US              36                                             

// *****************************************************************************
// *****************************************************************************
// Section: MCU INTERRUPT CONFIGURATION
// *****************************************************************************
// *****************************************************************************
/*********************************************************************************
  Function:
                CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT()
  Summary:
    Disables the global interrupt.
  Description:
    This function is called when entering into a critical section. It must
    provide an implementation to disable the interrupts globally. This
    \function must be very short, otherwise response time to the interrupt
    will take longer time. Define relevant function that has no arguments
    without return type.
  Conditions:
    None.
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT()   CRITICAL_SECTION_ENTER()
    
        void CRITICAL_SECTION_ENTER(void);
    
        void CRITICAL_SECTION_ENTER()
        {
          //Disable global interrupts
        }
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory                            
  *********************************************************************************/

#define CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT()                  UPD301_ENTER_CRITICAL()
/*******************************************************************************
  Function:
            CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT()
  Summary:
    Enables the global interrupt.
  Description:
    This function is called when exiting from critical section. It must
    provide an implementation to enable the interrupts globally. This
    \function must be very short, otherwise response time to the interrupt
    will take longer time. Define relevant function that has no arguments
    without return type.
  Conditions:
    None.
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT()   CRITICAL_SECTION_EXIT()
    
        void CRITICAL_SECTION_EXIT(void);
    
        void CRITICAL_SECTION_EXIT()
        {
            //Enable global interrupts
        }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                          
  *******************************************************************************/                           
#define CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT()                   UPD301_EXIT_CRITICAL()

/*Status of ports whether disabled or enabled*/
#define PORT_STATUS_DISABLED        0x01
#define PORT_STATUS_ENABLED         0x00

/**************************************************************************
  Function:
              CONFIG_HOOK_GPIO_INT_HW_INIT()
    
  Summary:
    Initializes the GPIO interrupt hardware handler. It is called only once and it 
    does the common initialization for all ports.
  Description:
    Initializes the GPIO interrupt hardware handler. It is called only once and it 
    does the common initialization for all ports.
  Conditions:
    None.
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_GPIO_INT_HW_INIT()      INT_ExtIrqHwInit()
    
        void INT_ExtIrqHwInit(void);
    
        void INT_ExtIrqHwInit(void)
        {
			//Initialize the GPIO intrrupt hardware.
        }
    </code>
  Remarks:
    User definition of this Hook function is optional
  **************************************************************************/
#define CONFIG_HOOK_GPIO_INT_HW_INIT()	INT_ExtIrqHwInit()

/**************************************************************************
  Function:
              CONFIG_HOOK_HW_UPDALERTGPIO_INIT(_u8Port_num_)
    
  Summary:
    Initializes the MCU GPIO that is connected to the alert line of a port's
    UPD350 for interrupt notification
  Description:
    This function initializes the MCU GPIO that is connected to the alert
    line of a port's UPD350 for interrupt notification. It is recommended to
    configure MCU GPIOs interrupt in edge level detection since the UPD350
    keeps the alert line in low state until the interrupt is cleared.
    Define relevant function that has port number as argument without return type.
  Conditions:
    None.
  Input:
    _u8Port_Num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_HW_UPDALERTGPIO_INIT(_u8Port_num_)      INT_ExtIrqInit(_u8Port_num_)
    
        void INT_ExtIrqInit(UINT8 u8Portnum);
    
        void INT_ExtIrqInit(UINT8 u8Portnum)
        {
            
			if(0 == u8Portnum)
			{
				//Initializes the MCU GPIO that is connected to Port 0's UPD350
			}
			if(1 == u8Portnum)
			{
				//Initializes the MCU GPIO that is connected to Port 1's UPD350
			}
        }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                     
  **************************************************************************/
#define CONFIG_HOOK_HW_UPDALERTGPIO_INIT(_u8Port_num_)	INT_ExtIrqInit(_u8Port_num_)

// *****************************************************************************
// *****************************************************************************
// Section: Reset UPD350 through MCU GPIO initialization
// *****************************************************************************
// *****************************************************************************
/**************************************************************************
  Function:
                CONFIG_HOOK_HW_UPDRESETGPIO_INIT(_u8Port_num_)
  Summary:
    Initializes the MCU GPIOs that are connected to the reset line of port's
    UPD350
  Description:
    This function initializes the MCU GPIOs that are connected to the reset
    line of the Port's UPD350. It is recommended to connect a single GPIO to the
    reset line of all UPD350s. Default line state of configured MCU GPIO
    must be high. Define relevant function that has port number as argument without
    \return type.
  Conditions:
    None.
  Input:
    _u8Port_Num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_HW_UPDRESETGPIO_INIT(_u8Port_num_)      updreset_init(_u8Port_num_)
    
    void updreset_init(UINT8 u8Portnum);
    
    void updreset_init(UINT8 u8Portnum)
    {
        if (0 == u8Portnum)
        {
            //Initialization of MCU GPIOs connected to UPD350 reset lines
            //Make the gpio line high as default
        }
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                      
  **************************************************************************/
#define CONFIG_HOOK_HW_UPDRESETGPIO_INIT(_u8Port_num_)               IRQ_ResetUPD350ThruGPIOInit(_u8Port_num_)

/**********************************************************************
  Function:
                CONFIG_HOOK_UPDRESET_THRU_GPIO(_u8Port_num_)
  Summary:
    Resets the UPD350 connected specific to the port. 
    User can implement common reset pin for all ports. in this case user must reset UPD350 only for port 0.
  
  Description:
    This function resets UPD350 connected to the port. Define relevant
    \function that has port number as argument without return type.
  Conditions:
    None.
  Input:
    _u8Port_Num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_UPDRESET_THRU_GPIO(_u8Port_num_)      updreset_thru_gpio(_u8Port_num_)
    
    void updreset_thru_gpio(UINT8 u8Portnum);
    
    void updreset_thru_gpio(UINT8 u8Portnum)
    {
        if (0 == u8Portnum)
        {
            //Enable pull down

           // Wait for xxx uS

           // Enable pull up
        }
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                  
  **********************************************************************/
#define CONFIG_HOOK_UPDRESET_THRU_GPIO(_u8Port_num_)              Reset_UPD350_Thru_MCU_GPIO(_u8Port_num_)

// *****************************************************************************
// *****************************************************************************
// Section: Structure packing
// *****************************************************************************
// *****************************************************************************
// *****************************************************************************

/**************************************************************************************************
  Summary:
    Structure packing to align the bytes in data memory based on the compiler.

  Description:
		Generally packed structures will be used to save space & align the bytes in data memory based on the compiler.
	If this pre-processor is defined then all used PD stack �C� structures will be replaced with keyword for compilation.
	If this pre-processor is not defined then it will be default compilation rules based on the compiler.

  Remarks:
    Need to be packed always based on type of microcontroller.
	
  Example:
  <code>
	#define CONFIG_STRUCT_PACKED_START   __attribute__((__packed__)) 
  </code>
**************************************************************************************************/
#define CONFIG_STRUCT_PACKED_START   
/**************************************************************************************************
Summary:
Structure packing to align the bytes in data memory based on the compiler.

Description:
Generally packed structures will be used to save space & align the bytes in data memory based on the compiler.
If this pre-processor is defined then all used PD stack �C� structures will be replaced with keyword for compilation.
If this pre-processor is not defined then it will be default compilation rules based on the compiler.

Remarks:
Need to be packed always based on type of microcontroller.

Example:
<code>

</code>
**************************************************************************************************/
#define CONFIG_STRUCT_PACKED_END    __attribute__((pack(4)))
// *****************************************************************************
// *****************************************************************************
// Section: UPD350 Hardware Interface Configuration
// *****************************************************************************
// *****************************************************************************

/**************************************************************************
  Function:
            CONFIG_HOOK_UPD_HW_INTF_INIT()
    
  Summary:
    Initialize the hardware interface(SPI/I2C) used for communicating with UPD350 part.
  Description:
    UPD350 supports both I2C and SPI interface. Depending on the UPD350 part used,
    the hardware communication interface between the SOC and UPD350 
    differs. UPD350 A and C supports I2C interface and UPD350 B and D part 
    supports SPI interface. This function is to initialise the interface as 
    required.It is called during initialization of stack. Define relevant 
    function that has no arguments without return type.
  Conditions:
    Use SPI interface for part UPD350 B and D.
    Use I2C interface for part UPD350 A and C.
  Return:
    None.
  Example:
    <code>
        #define CONFIG_HOOK_UPD_HW_INTF_INIT()      hw_spi_init()
    
        void hw_spi_init( void );
    
        void hw_spi_init( void )
        {
            //Intialise SOC's SPI master
        }
    
    </code>
         <code>
        #define CONFIG_HOOK_UPD_HW_INTF_INIT()      hw_i2c_init()
    
        void hw_i2c_init( void );
    
        void hw_i2c_init( void )
        {
            //Initialise SOC's I2C master
        }
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory                     
  **************************************************************************/
#define CONFIG_HOOK_UPD_HW_INTF_INIT()                                                   SPI_Init()

/*************************************************************************************************
  Function:
              CONFIG_HOOK_UPD_HW_INTF_COMM_EN(_u8Port_Num_)
    
  Summary:
    Enable hardware interface(SPI/I2C) to the port's(TODO) UPD350 for communication
    
  Description:
    This function is called before starting read/write operations of UPD350
    registers with respect to the port.This is to enable hardware 
    interface(I2C/SPI) communication to the port's UPD350 if required.

    For SPI interface, SPI chip select level shall be driven 
    low with respect to the port number given in the argument of this function 
    to enable SPI communication with port's UPD350.

    For I2C interface, I2C mux shall be configured to route the SOC's I2C master
    to the port number given in the argument of this function 
    to enable I2C communication with port's UPD350.
    
    Define relevant function that has one UINT8 argument with out return type.    

  Conditions:
    None.
  Input:
    _u8Port_Num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    
        \#define CONFIG_HOOK_UPD_HW_INTF_COMM_EN(_u8Port_Num_)      hw_spi_cs_low (_u8Port_Num_)
    
        void hw_spi_cs_low(UINT8 u8Portnum);
    
        void hw_spi_cs_low (UINT8 u8Portnum)
        {
            if (u8Portnum == 0)
            {
                //Set pin level low for respective GPIO 
                    that is connected to the UPD350 SPI CS pin
            }
            if (u8Portnum == 1)
            {
                //Set pin level low for respective GPIO 
                    that is connected to the UPD350 SPI CS pin
            }
        }
    
    </code>

    <code>
    
        \#define CONFIG_HOOK_UPD_HW_INTF_COMM_EN(_u8Port_Num_)      hw_enable_port_i2cmux_routing (_u8Port_Num_)
    
        void hw_enable_port_i2cmux_routing(UINT8 u8Portnum);
    
        void hw_enable_port_i2cmux_routing (UINT8 u8Portnum)
        {
            if (u8Portnum == 0)
            {
                //Route the I2C mux to the Port 0
            }
            if (u8Portnum == 1)
            {
                //Route the I2C mux to the Port 1
            }
        }
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory for SPI Hardware interface                                           
  *************************************************************************************************/
#define CONFIG_HOOK_UPD_HW_INTF_COMM_EN(_u8Port_num_)                                       SPI_ChipSelectLow(_u8Port_num_)

/**********************************************************************************************
  Function:
                CONFIG_HOOK_UPD_HW_INTF_COMM_DIS(_u8Port_num_)
    
  Summary:
    Disable hardware interface(SPI/I2C) to the port's UPD350 for communication


  Description:
    This function is called after finishing read/write operations of UPD350
    registers with respect to the port.This is to disable hardware 
    interface(I2C/SPI) communication to the port's UPD350 if required.

    For SPI interface, SPI chip select level shall be driven 
    high with respect to the port number given in the argument of this function 
    to disable SPI communication with port's UPD350.

    For I2C interface, I2C mux routing the SOC's I2C master to the port number 
    given in the argument of this function shall be disabled.
    
    Define relevant function that has one UINT8 argument with out return type.

  Conditions:
    None.
  Input:
    _u8Port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_UPD_HW_INTF_COMM_DIS(_u8Port_num_)      hw_spi_cs_high (_u8Port_num)
    
        void hw_spi_cs_high(UINT8 u8Portnum);
    
        void hw_spi_cs_high (UINT8 u8Portnum)
        {
            if (u8Portnum == 0)
            {
                //Set pin level high for respective GPIO that is connected to 
                    the UPD350 CS pin
            }
            if (u8Portnum == 1)
            {
                //Set pin level high for respective GPIO that is connected to 
                    the UPD350 CS pin
            }
        }
    
    
    </code>
    
    <code>
    
        \#define CONFIG_HOOK_UPD_HW_INTF_COMM_EN(_u8Port_Num_)      hw_disable_port_i2cmux_routing (_u8Port_Num_)
    
        void hw_disable_port_i2cmux_routing(UINT8 u8Portnum);
    
        void hw_disable_port_i2cmux_routing (UINT8 u8Portnum)
        {
            if (u8Portnum == 0)
            {
                //disbale the I2C mux routing to the Port 0
            }
            if (u8Portnum == 1)
            {
                //disbale the I2C mux routing to the Port 1
            }
        }
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory for SPI Hardware interface                                         
  **********************************************************************************************/
#define CONFIG_HOOK_UPD_HW_INTF_COMM_DIS(_u8Port_num_)                                      SPI_ChipSelectHigh(_u8Port_num_)

/*********************************************************************************************
  Function:
                CONFIG_HOOK_UPD_HW_INTF_WRITE_TRANSFER(_u8Port_num_,_pu8write_buf_,_u16write_len_)
    
  Summary:
    Function to initiate a write transfer to UPD350 via I2C/SPI
  Description:
    This function is called to write to UPD350 registers specific to the port.
    This function definition must be confined to the definition 
    CONFIG_DEFINE_UPD350_HW_INTF_SEL.
    
    Define relevant function that has UINT8, UINT8*, UINT16 arguments
    without return type.
  Conditions:
    None.
  Input:
    _u8Port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT.
    _pu8write_buf_ -  Stack shall pass the pointer to the buffer which has the data
                      to be written on the SPI/I2C Hardware bus. Data type of 
                      the pointer buffer must be UINT8*.
    _u16write_len_ -  Stack shall pass the Number of bytes to be written on
                      the SPI/I2C Hardware bus. Data type of this parameter must be
                      UINT16.
  Return:
    None.
  Example:
    <code>
        #define CONFIG_HOOK_UPD_HW_INTF_WRITE_TRANSFER(_u8Port_num_,_pu8write_buf_,_u16write_len_)   
                                                    SPI_Write (_u8Port_num_,_pu8write_buf_, _u16write_len_)
    
        void SPI_Write(UINT8 _u8Port_num_, UINT8 *pu8WriteBuffer, UINT16 u16Writelength);
    
        void SPI_Write(UINT8 _u8Port_num_, UINT8 *pu8WriteBuffer, UINT16 u16Writelength)
        {
            for(UINT16 u16Txcount = 0; u16Txcount \< u16Writelength ;u16Txcount++)
            {
                //Write data bytes to SPI bus
            }
        }
    </code>
     <code>
        #define CONFIG_HOOK_UPD_HW_INTF_WRITE_TRANSFER(_u8Port_num_,_pu8write_buf_,_u16write_len_)   
                                                    I2C_Write (_u8Port_num_,_pu8write_buf_, _u16write_len_)
    
        void I2C_Write(UINT8 _u8Port_num_, UINT8 *pu8WriteBuffer, UINT16 u16Writelength);
    
        void I2C_Write(UINT8 _u8Port_num_, UINT8 *pu8WriteBuffer, UINT16 u16Writelength)
        {
            // Select I2C address for the UPD350 I2C slave using _u8Port_num_ 
         
            for(UINT16 u16Txcount = 0; u16Txcount \< u16Writelength ;u16Txcount++)
            {
                //Write data bytes to I2C bus
            }
        }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                                        
  *********************************************************************************************/
#define CONFIG_HOOK_UPD_HW_INTF_WRITE_TRANSFER(_u8Port_num_,_pu8write_buf_,_u16write_len_)                   SPI_Write (_u8Port_num_,_pu8write_buf_,_u16write_len_)

/***************************************************************************************
  Function:
          CONFIG_HOOK_UPD_HW_INTF_READ_TRANSFER(UINT8 _u8Port_num_,_pu8read_buf_, _u16read_len_)
    
  Summary:
    Function to initiate a read transfer to UPD350 via I2C/SPI
  Description:
    This function is called to read to UPD350 registers with respect to the
    port.
    This function definition must be confined to the definition 
    CONFIG_DEFINE_UPD350_HW_INTF_SEL.
    
    Define relevant function that has UINT8, UINT8*, UINT16 arguments
    without return type.
    
  Conditions:
    None.
  Input:
    _u8Port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT.
    _pu8read_buf_ -  Stack will pass the pointer to the buffer where data to
                     be read on the SPI bus. Data type of the pointer buffer
                     must be UINT8*
    _u16read_len_ -  Stack will pass the number of bytes to be read on the
                     SPI bus. Data type of this parameter must be UINT16
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_UPD_HW_INTF_READ_TRANSFER(_u8Port_num_,_pu8read_buf_, _u16read_len_)  \\
                                                 SPI_Read (_u8Port_num_,_pu8read_buf_, _u16read_len_)
    
        void SPI_Read (UINT8 _u8Port_num_, UINT8 *pu8ReadBuffer, UINT16 u16Readlength)
    
        void SPI_Read (UINT8 _u8Port_num_, UINT8 *pu8ReadBuffer, UINT16 u16Readlength)
        {
            for(UINT16 u16Rxcount = 0; u16Rxcount \< u16Readlength; u16Rxcount++)
            {
                //Read data from SPI bus
             }
        }
    </code>
    <code>
        \#define CONFIG_HOOK_UPD_HW_INTF_READ_TRANSFER(_u8Port_num_,_pu8read_buf_, _u16read_len_)  \\
                                                 I2C_Read (_u8Port_num_,_pu8read_buf_, _u16read_len_)
    
        void I2C_Read (UINT8 _u8Port_num_, UINT8 *pu8ReadBuffer, UINT16 u16Readlength)
    
        void I2C_Read (UINT8 _u8Port_num_, UINT8 *pu8ReadBuffer, UINT16 u16Readlength)
        {
            // Select I2C address for the UPD350 I2C slave using _u8Port_num_ 
            for(UINT16 u16Rxcount = 0; u16Rxcount \< u16Readlength; u16Rxcount++)
            {
                //Read data from I2C bus
             }
        }
    </code>
  Remarks:
    User definition of this Hook function is mandatory                                  
  ***************************************************************************************/
#define CONFIG_HOOK_UPD_HW_INTF_READ_TRANSFER(_u8Port_num_,_pu8read_buf_, _u16read_len_)                     SPI_Read (_u8Port_num_,_pu8read_buf_, _u16read_len_)
                                           
/************************************************************************
  Function:
          \#define CONFIG_HOOK_MEMCMP(_OBJ1_, _OBJ2_, _LEN_)
  Summary:
    Compare two memory regions
  Description:
    This function is called to compare two memory regions _OBJ1_ &amp;
    _OBJ2_ with specified length _LEN_. USER_APPLICATION must define this
    \function based on compiler of MCU.
  Conditions:
    None.
  Input:
    _OBJ1_ -  This is the pointer to block of Memory region 1
    _OBJ2_ -  This is the pointer to block of Memory region 2
    _LEN_ -   This is the number of bytes to be compared.
  Return:
    \Returns 0 if two memory regions are same.
  Example:
    <code>
    \#define CONFIG_HOOK_MEMCMP(_OBJ1_, _OBJ2_, _LEN_)  \\
                                           memcmp(_OBJ1_, _OBJ2_, _LEN_)
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory                   
  ************************************************************************/
#define CONFIG_HOOK_MEMCMP(_OBJ1_, _OBJ2_, _LEN_)                                   UPD301_MemCmp(_OBJ1_, _OBJ2_, _LEN_)

/**************************************************************************
  Function:
            \#define CONFIG_HOOK_MEMCPY(_DEST_, _SRC_, _LEN_)
    
  Summary:
    Copies one memory area to another memory area
  Description:
    This function is called to copy _LEN_ bytes from _SRC_ memory area to
    _DEST_ memory area. USER_APPLICATION must define this function based on
    compiler of MCU. The memory areas must not overlap.
  Conditions:
    None.
  Input:
    _DEST_ -  This is the pointer to block of destination memory region
    _SRC_ -   This is the pointer to block of source memory region
    _LEN_ -   This is the number of bytes to be copied.
  Return:
    \Returns a pointer to _DEST_.
  Example:
    <code>
    \#define CONFIG_HOOK_MEMCPY(_DEST_, _SRC_, _LEN_)  \\
                                      memcpy(_DEST_, _SRC_, _LEN_)
    
    //This function definition can be compiler defined or user defined
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory                     
  **************************************************************************/
#define CONFIG_HOOK_MEMCPY(_DEST_, _SRC_, _LEN_)                                     UPD301_MemCpy(_DEST_, _SRC_, _LEN_)


         
                                                                                          
/**************************************************************************
  Function:
                \#define CONFIG_HOOK_GETCURRENT_IMAGEBANK()
  Summary:
    To Return the Index of the Image Bank which is currently executing.
    
    \Example:
    
    \1. 0x00 - Corresponds to Bootloader Application
    
    \2. 0x01 - Corresponds to Fixed Application
    
    \3. 0x02 - Corresponds to Updatable Application
  Description:
    This function is called to get the Index of the Image Bank which is
    currently executing. Zeus Stack follows "Architecture 2 - Fixed base
    application with updatable application image" In which the Fixed
    Application is Image Bank 1 and Updatable Application is Image Bank 2.
  Conditions:
    This function is invoked by the PD Firmware Update State-machine during
    the Enumeration Phase (On reception PDFU_GET_FW_ID Command).
    
    
  Return:
    \Returns Byte Value -That is the index of the Image Bank.
    
    IMAGE_BANK_BOOTLOADER 0x01
    
    IMAGE_BANK_FIXED_APP 0x02
    
    IMAGE_BANK_UPDATABLE_APP 0x03
  Example:
    <code>
    \#define CONFIG_HOOK_GETCURRENT_IMAGEBANK()  getCurrentImageBank()
    
    UINT8 getCurrentImageBank(void)
    {
       \return u8ImageBankIndex;
    
    }
    
    </code>
  Remarks:
    The User definition of the function is mandatory in both Fixed and
    Updatable application when INCLUDE_PDFU is TRUE.                 
  **************************************************************************/

#define CONFIG_HOOK_GETCURRENT_IMAGEBANK()  gu8CurrentMemory

/****************************************************************************************
  Function:
              \#define CONFIG_HOOK_PROGRAM_FWBLOCK( _OBJ1_,_LEN_)
  Summary:
    Validate the Data block and program the data to the Memory, and return
    the Status of the Programming Operation.
  Description:
    This Function is invoked during the Transfer Phase on the Successful
    reception event of every PDFU DATA packet. This function is responsible
    for Updating the Firmware data to the memory, and identifying any
    errors during the Firmware flash.
  Conditions:
    Only during the Policy Engine State -Reconfigure Phase or Transfer
    Phase this function will be invoked.
  Input:
    _OBJ1_ -  UINT8 Pointer to PDFU_DATA packet payload Buffer.<p /><p />_OBJ1_[0]
              \- Reserved field \- Contains PD FW Version.<p />_OBJ1_[1] \-
              Reserved field \- Contains Msg Type which is PDFU_DATA\-0x83.<p />_OBJ1_[2]
              \- LSB of Data Block Index.<p />_OBJ1_[3] \- MSB of Data Block
              Index<p />_OBJ1_[4..260] \- Firmware Image data upto 256
              bytes.<p /><p />Where, the Data block index is used to
              calculate the Physical memory address to which the current
              data block corresponds to.<p /><p />
    _LEN_ -   16 bit parameter \- Indicates the length of the Firmware data
              contained in the packet.
  Return:
    \Returns ePE_PDFU_RESPONSE_CODE Type Return Value - The Status of the
    Program Operation.
    
      * ePE_FWUP_OK &#45; Upon successful flash operation.
      * ePE_FWUP_errVERIFY &#45; When verification of the flash operation
        failed.
      * ePE_FWUP_errADDRESS &#45; when data block index is out of range.
  Example:
    <code>
    \#define CONFIG_HOOK_PROGRAM_FWBLOCK(_OBJ1_, _LEN_)     (PDFW_ProcessPDFUDataRequest)
    
    </code>
    ePE_PDFU_RESPONSE_CODE PDFW_ProcessPDFUDataRequest( UINT8
    \*u8RequestBuffer, UINT16 u16RequestLength)
    
    {
    
    UINT16 u16DataBlockIndex = *((UINT16*)&amp;u8RequestBuffer[2]);
    
    
    
    u32ProgAddr = CalculateAddress(u16DataBlockIndex);
    
    
    
    if( u32ProgAddr \< 0xFFFFu )
    
    {
    
    
    
    ProgramMemoryCB(u32ProgAddr, &amp;u8RequestBuffer[4u],
    u16RequestLength);
    
    
    
    ReadMemoryCB(u32ProgAddr, &amp;u8ResponseBuffer[0u], u16RequestLength);
    
    
    
    Compare data written and read;
    
    if (CONFIG_HOOK_MEMCMP(&amp;u8ResponseBuffer[0], &amp;u8RequestBuffer[4],
    u16RequestLength) == 0)
    
    {
    
    Set the status as OK;
    
    u8Status = ePE_FWUP_OK;
    
    }
    
    else
    
    {
    
    Verification Stage failure;
    
    u8Status = ePE_FWUP_errVERIFY;
    
    }
    
    }
    
    else
    
    {
    
    u8Status = ePE_FWUP_errADDRESS;
    
    }
    
    
    
    \return u8Status;
    
    }
    <code>
    
    </code>
  Remarks:
    \ \ 
    
    User definition of this Hook function is mandatory when
    INCLUDE_PDFU is TRUE.                                                          
  ****************************************************************************************/

#define CONFIG_HOOK_PROGRAM_FWBLOCK(_OBJ1_,_LEN_)  PDFW_ProcessPDFUDataRequest(_OBJ1_,_LEN_)

/**************************************************************************************************
  Function:
                \#define CONFIG_HOOK_VALIDATE_FIRMWARE(_OBJ1_,_LEN_)
  Summary:
    To validate the Flashed Binary using a User defined validation method
    and return the Status of the Firmware Validation Operation.
  Description:
    This Function is invoked during the validation phase on reception of
    every PDFU Validation Request.
    
    This function is responsible for Validating the Firmware data in the
    memory. The Function shall return the progress status of the Validation
    on every invocation. If the Status indicates "On going" then the
    Validation command will be responded with the configured Wait time.
    
    
    
    Validation Method can be any Custom method as required by the User.
  Conditions:
      * Multiple invocations of the function is possible from PDFU
        Validation phase.
    
    Until the Validation process is complete, for every request of
    PDFU_VALIDATION command this function will be invoked.
    
    
    
    The definition of this function shall include 1) Starting the
    Validation process on the First call, 2) Returning the Status of the
    Validation process during subsequent invocation of the function.
  Return:
    \Returns the UINT8 Status of the Validation Operation.
      * PE_FWUP_VALIDATION_SUCCESSFUL 0x00u
      * PE_FWUP_VALIDATION_INPROGRESS 0x01u
      * PE_FWUP_VALIDATION_FAILURE 0x02u
  Example:
    <code>
    \#define CONFIG_HOOK_VALIDATE_FIRMWARE() (PDFW_ProcessPDFUDataRequest)
    
    UINT8 PDFW_ProcessPDFUValidateRequest(void)
    {    
    
    The definition of this function shall include
    1) Starting the Validation process on the First call,
    2) Returning the Status of the Validation process during subsequent invocation of the function.
    
    }
    
    </code>
  Remarks:
    User definition of this Hook function is mandatory when INCLUDE_PDFU is
    TRUE                                                                                           
  **************************************************************************************************/

#define CONFIG_HOOK_VALIDATE_FIRMWARE()  PDFW_ProcessPDFUValidateRequest()

/**************************************************************************
  Function:
                    \#define CONFIG_HOOK_BOOT_FIXEDAPPLICATION()
  Summary:
    CONFIG_HOOK_BOOT_FIXEDAPPLICATION shall perform necessary operation to
    switch from Updatable application to Fixed application.
  Description:
    Re-flash of the Updatable_Application image bank while currently
    executing in the Updatable_Application image bank, requires switch to
    Fixed application for performing the upgrade.
    
    The application switching may include invalidating the
    Updatable_Application signatures (and/or) jump/reset for fresh boot
    from Fixed application.
  Conditions:
    This function is invoked by the PD Firmware Update State-machine during
    the Reconfiguration phase(On reception PDFU_INITIATE Command), when the
    Updatable application is currently running.
  Return:
    No Return Value. During execution of this function the control shall be
    switched to the Fixed application.
  Example:
    <code>
    \#define CONFIG_HOOK_BOOT_FIXEDAPPLICATION()   Boot_Fixed_Application()
    
    void Boot_Fixed_Application(void)
    {
    </code>
    <c> UPD301_EraseUpdatableAppSignature(); //Invalidate the Updatable app
    sign</c>
    <code>
        UPD301_Reset() //Reset to boot from Fixed app
    }
    </code>
  Remarks:
    User definition of this Hook function is mandatory in the Updatable
    application when INCLUDE_PDFU is TRUE                            
  **************************************************************************/

#define CONFIG_HOOK_BOOT_FIXEDAPPLICATION()     UPD301_EraseUpdatableAppSignature();\
                                                UPD301_DetachPorts();\
                                                UPD301_Reset()
 /***********************************************************************************
   Function:
                         \#define CONFIG_HOOK_BOOT_UPDATABLE_APPLICATION()
   Summary:
     CONFIG_HOOK_BOOT_UPDATABLE_APPLICATION shall perform necessary
     operation to boot from the updatable application after a PDFU is
     successfully completed.
   Description:
     As the flashing operation is executed from the Fixed application, once
     the PDFU process is complete it is necessary to switch to the newly
     upgraded updatable application.
     
     
     
     This function definition shall implement necessary operations to safely
     exit the fixed application and boot from the updatable application.
     
     The application switching may include setting the valid
     Updatable_Application signatures (and) jump/reset for fresh boot from
     Updatable application.
   Conditions:
     This function is invoked by the PD Firmware Update State-machine during
     the Manifestation phase(On reception PDFU_INITIATE Command), when the
     Fixed application is currently running.
   Return:
     No Return Value. During execution of this function the control shall be
     switched to the Updatable application.
   Example:
     <code>
     \#define CONFIG_HOOK_BOOT_UPDATABLE_APPLICATION()   Boot_Updatable_Application()
     
     void Boot_Updatable_Application(void)
     {
         UPD301_Reset() //Reset to boot from Fixed app
     }
     </code>
   Remarks:
     User definition of this Hook function is mandatory in the Fixed
     application when INCLUDE_PDFU is TRUE                                     
   ***********************************************************************************/ 

#define CONFIG_HOOK_BOOT_UPDATABLE_APPLICATION()              UPD301_DetachPorts();\
                                                              UPD301_Reset()
                                                  
   /**************************************************************************
     Function:
             \#define CONFIG_HOOK_IS_PDFU_ALLOWED_NOW()
     Description:
       CONFIG_HOOK_IS_PDFU_ALLOWED_NOW specifies if PD Firmware Update can be
       currently allowed, based on the priority of the application tasks
       currently executing.
       
       
       
       \1. When the PD Firmware Update is allowed, the PDFU Initiator can
       perform firmware upgrade by the PDFU Sequence
       
       \2. When the PD Firmware Update is not allowed, the PDFU Initiator is
       responded with the error code during the Reconfiguration phase.
       
       
       
       \Example scenario of When PDFU cannot be allowed:
       
       Assuming a product with firmware update capability through CC and I2C
       as well. In an example, if the firmware upgrade through I2C is already
       in progress, then PDFU through CC interface shall not be allowed. To
       handle such situations, this macro shall return the current status of
       allowability of firmware upgrade.
     Conditions:
       This function is invoked by the PD Firmware Update State-machine during
       the Reconfiguration Phase (On reception PDFU_INITIATE Command).
     Remarks:
       Shall return the run time status whether PDFU is allowed now or not.
     Return:
       UINT8 value
       
       
       
       0x00 - PDFU Not Allowed.
       
       0x01 - PDFU Allowed.
       
       
     Example:
       <code>
       \#define CONFIG_HOOK_IS_PDFU_ALLOWED_NOW   isPdfuAllowedNow()
       
       UINT8 isPdfuAllowedNow(void)
       {
           \return u8PdfuAllow;
       }
       </code>
                                                                              
     **************************************************************************/
#define CONFIG_HOOK_IS_PDFU_ALLOWED_NOW()   (FALSE == gu8HermesConnectionActive)

// *****************************************************************************
// *****************************************************************************
// Section: Power Fault APIs
// *****************************************************************************
// *****************************************************************************


/*********************************************************************************
  Function:
                CONFIG_HOOK_NOTIFY_POWER_FAULT(_u8PortNum_, _pu8PwrFaultsts_)
  Summary:
    Power Fault Notification from stack.

  Description:
    This hook notifies the type of Power fault that has occurred from DPM Power Fault 
    Manager. 
    This Hook gives user have options to
            i)  Ignore power fault handling for that instance of DPM Power fault manager:
                User should return FALSE to ignore the instance.
            ii) Ignore the power fault occurrence:
                User should clear the fault occurrence indication in  power fault status
                pointer  _pu8PwrFaultsts_ as well as return FALSE to ignore the instance.
            iii) Allow DPM power fault handler to handle it:
                User should return TRUE for DPM power fault manager to handle it.
                Incase of explicit contract and power fault count is less than 
                CONFIG_MAX_VBUS_POWER_FAULT_COUNT, DPM power fault manager handles
                by sending Hard Reset. Incase of implicit contract, it handles by
                entering TypeC Error Recovery. 
                
  Conditions:
    None. 

 Input:
    _u8Port_Num_    -  Port number of the device. Value passed will be less
                        than CONFIG_PD_PORT_COUNT
    _pu8PwrFaultsts_ - Pointer to Power fault status for the port. The value *_pu8PwrFaultsts_
                        can be interpreted from following.
                        BIT(0) - DPM_POWER_FAULT_OVP (Over voltage fault)          
                        BIT(1) - DPM_POWER_FAULT_UV (Under voltage)
                        BIT(2) - DPM_POWER_FAULT_VBUS_OCS (VBUS Over-current fault)
                        BIT(3) - DPM_POWER_FAULT_VCONN_OCS (VCONN over-current fault)
                        This pointer can be modified to disable the occurred power fault.

  Return:
    UINT8 is the return value. Depending on the return value occurred Power fault is handled
    by DPM Power Fault Manager.
    Return value can be
	TRUE - for stack to handle occurred power fault 
    FALSE - for stack to neglect the Power fault occurred for that instance
    Note that returning FALSE will not reset power fault that has occurred. 
    It is ignored Power fault handling for that instance alone.

  Example:
    <code>
        \#define CONFIG_HOOK_NOTIFY_POWER_FAULT(_u8PortNum_, _pu8PwrFaultsts_)  

        UINT8 UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts);

        UINT8 UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts)
        {
            Return DPM_HANDLE_PWR_FAULT(TRUE) to handle occured power fault.
            Return DPM_NEGLECT_PWR_FAULT(FALSE) to neglect the Power fault occurred 
                                                for that instance.
            Return DPM_NEGLECT_PWR_FAULT(FALSE) and reset the power fault status to
                                        ignore the power fault occurred completely.
        }

    </code>
  Remarks:
    User definition of this Hook function is mandatory.
  *********************************************************************************/
                                              
#define CONFIG_HOOK_NOTIFY_POWER_FAULT(_u8PortNum_, _pu8PwrFaultsts_)	UPD301_HandlePowerFault(_u8PortNum_, _pu8PwrFaultsts_)
                                              
/*********************************************************************************
  Function:
                CONFIG_HOOK_NOTIFY_POWER_FAULT_FROM_ISR(_u8PortNum_, _pu8PwrFaultsts_)
  Summary:
    Power Fault notification from ISR 

  Description:
    This function hook is to notify Power Fault (OVP, UV and OCS) occurrence from ISR 
    as soon as it is detected. 
    The notification hook can be used for the following:
        i)Reset the VBUS_EN to cutoff the power 
            incase INCLUDE_UPD_PIO_OVERRIDE_SUPPORT is not enabled.
        ii)Trigger any VBUS correction mechanism to correct the Power fault condition 
            that as occurred.
        iii)Validate the Power fault occurred and nullify the occurrence incase it is
            not valid. To nullify a power fault occurrence, user shall clear
            the fault occurrence indication in  power fault status pointer  
 *          _pu8PwrFaultsts.
            

   Conditions:
    The Hook is called within a ISR handler it should as short as possible.
    This Hook definition must not enable any interrupt.

 Input:
    _u8Port_Num_    -  Port number of the device. Value passed will be less
                        than CONFIG_PD_PORT_COUNT
    _pu8PwrFaultsts_ - Pointer to Power fault status for the port. The value *_pu8PwrFaultsts_
                        can be interpreted from following.
                        BIT(0) - DPM_POWER_FAULT_OVP (Over voltage fault)          
                        BIT(1) - DPM_POWER_FAULT_UV (Under voltage)
                        BIT(2) - DPM_POWER_FAULT_VBUS_OCS (VBUS Over-current fault)
                        BIT(3) - DPM_POWER_FAULT_VCONN_OCS (VCONN over-current fault)
                        This pointer can be modified to disable the occurred power fault.

  Return:
    None.

  Example:
    <code>
        \#define CONFIG_HOOK_NOTIFY_POWER_FAULT_FROM_ISR(_u8PortNum_, _pu8PwrFaultsts_)  

        void UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts);

        void UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts)
        {
           Drive VBUS_EN low or cut off the power if necessary on a power fault. 
        }

    </code>
  Remarks:
    User definition of this Hook function is optional. 
  *********************************************************************************/
                                              
#define CONFIG_HOOK_NOTIFY_POWER_FAULT_FROM_ISR(_u8PortNum_, _pu8PwrFaultsts_)                                            

// *****************************************************************************
// *****************************************************************************
// Section: GPIO APIs
// *****************************************************************************
// *****************************************************************************


#define CONFIG_HOOK_UPD350_GPIO_INIT(_u8PortNum_)


// *****************************************************************************
// *****************************************************************************
// Section: Header files of User Application required for PSF stack operation.
// *****************************************************************************
// *****************************************************************************

#include "portpower_control.h"
#include "UPD301_App.h"

#include "Board_Config.h"

#endif
