/*
	dac.h

	File Description
	This file contains one & only the Global variables that are NOT exposed to the end user
	or in DOS

	Copyright(C) 2015, Microchip Technology Inc. All Rights Reserved.

	This program code listing is proprietary to Microchip and may not be copied,  
	distributed, or used without a license to do so. Such license may have  
	Limited or Restricted Rights. Please refer to the license for further clarification.

	THIS SOFTWARE IS PROVIDED IN AN ?AS IS? CONDITION. NO WARRANTIES,
	WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
	TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
	PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
	IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
	CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*/

#ifndef _DAC_H_
#define _DAC_H_

/**Bit defines*/
#define BIT7	BIT(7)
#define BIT6	BIT(6)
#define BIT5	BIT(5)
#define BIT4	BIT(4)
#define BIT3	BIT(3)
#define BIT2	BIT(2)
#define BIT1	BIT(1)
#define BIT0	BIT(0)

/********************** Register Definitions of DAC module ********************/
#define DAC_BASE_ADDRESS    0x42004800UL
/* ========== Instance parameters for DAC peripheral ========== */
#define DAC_GCLK_INDEX                 26

/* -------- Register : DAC_CTRLA : (DAC Offset: 0x0) (R/W  8) Control A -------- */
#define DAC_CNTRLA_B_SWRST    BIT0    /*!< bit:0  Software Reset       */
#define DAC_CNTRLA_B_ENABLE   BIT1    /*!< bit:1  Enable               */
#define DAC_CNTRLA_B_RUNSTDBY BIT2    /*!< bit:2  Run in Standby       */
#define DAC_CTRLA_ADDROFFSET  0x0u    /**< \brief (DAC_CTRLA offset) Control A */

/* -------- Register : DAC_CTRLB : (DAC Offset: 0x1) (R/W  8) Control B -------- */

#define DAC_CTRLB_B_EOEN    BIT0        /**< \brief (DAC_CTRLB) External Output Enable */
#define DAC_CTRLB_B_IOEN    BIT1        /**< \brief (DAC_CTRLB) Internal Output Enable */
#define DAC_CTRLB_B_LEFTADJ BIT2        /**< \brief (DAC_CTRLB) Left Adjusted Data */
#define DAC_CTRLB_B_VPD     BIT3        /**< \brief (DAC_CTRLB) Voltage Pump Disable */
#define DAC_CTRLB_START_REFSEL  6u      /**< \brief (DAC_CTRLB) 2 bit Reference Selection starting bit */
#define DAC_CTRLB_ADDROFFSET    0x1u    /**< \brief (DAC_CTRLB offset) Control B */

/* -------- Register : DAC_STATUS : (DAC Offset: 0x7) (R/8) Status -------- */
#define DAC_STATUS_B_SYNCBUSY   BIT7       /*!< bit:7  Synchronization Busy Status*/
#define DAC_STATUS_ADDROFFSET   0x7u          /**< \brief (DAC_STATUS offset) Status */

/* -------------------------Register : DATA -------------------------------- */
#define DAC_DATA_ADDROFFSET     0x8u          /**< \brief (DAC_DATA offset) Data */



/*------------------DAC Module Macro definitions------------------------------*/

/**-----------Macro for synchronization wait between Interface clock and GCLK-----------*/
#define DAC_WAIT_FOR_SYNC()  	while ((REGB(DAC_BASE_ADDRESS + DAC_STATUS_ADDROFFSET) & DAC_STATUS_B_SYNCBUSY) != FALSE)

/**-----------Check if DAC module is already enabled through CNTRLA register-----------*/
#define DAC_CNTRLA_ISENABLE()   ((REGB(DAC_BASE_ADDRESS + DAC_CTRLA_ADDROFFSET) & DAC_CNTRLA_B_ENABLE) != FALSE)

/**-----------Perform DAC Module reset-----------**/
#define DAC_MODULE_RESET()      (REGB(DAC_BASE_ADDRESS + DAC_CTRLA_ADDROFFSET) |= DAC_CNTRLA_B_SWRST )



/*********************   Enum Definitions        ******************************/

/**Enum for DAC Initilization status*/
typedef enum {
    eDAC_INIT_ERROR = 0x00,
    eDAC_INIT_SUCCESS
}eDAC_INIT_RETURN;

/**Enum for DAC Reference Voltage selection*/
typedef enum {
    eDAC_REFSEL_INTERNAL1V = 0,  /**< \brief (DAC_CTRLB) Internal 1.0V reference */
    eDAC_REFSEL_ANALOGVCC = 1,   /**< \brief (DAC_CTRLB) AVCC */
    eDAC_REFSEL_VREFPIN = 2     /**< \brief (DAC_CTRLB) External reference */
}eDAC_VREF_SELECT;


/*--------Macros related to PMPD module----------*/

/**DAC Data register values for PMPD module to select the VBUS voltages**/
/**Calculated as DAC Vout = (Voltage_ref/0x3ff) * DATA */
#define DAC_PDPM_0V_DIGITAL_SAMPLE            0x00u
#define DAC_PDPM_5V_DIGITAL_SAMPLE            214u
#define DAC_PDPM_9V_DIGITAL_SAMPLE            374u
//#define DAC_PDPM_12V_DIGITAL_SAMPLE           613u
#define DAC_PDPM_15V_DIGITAL_SAMPLE           614u
#define DAC_PDPM_20V_DIGITAL_SAMPLE           814u

/* DAC step values for 8.4 scale */
#define DAC_PDPM_0V_STEP            0.0
#define DAC_PDPM_5V_STEP            0.637
#define DAC_PDPM_9V_STEP            1.113
#define DAC_PDPM_15V_STEP           1.827
#define DAC_PDPM_20V_STEP           2.423

/* DAC step values for sink current operation */
#define DAC_STEPS_0A        0
#define DAC_STEPS_0P5A      0.25
#define DAC_STEPS_1P5A      0.75
#define DAC_STEPS_2A        1.0
#define DAC_STEPS_3A        1.5
#define DAC_STEPS_5A        2.5

/*--------Macros related to DAC conversion Delay calculations ----------*/
#define SYSTEM_CLOCK_MHZ                48u
#define NUM_NOP_INSTRUCTIONS            10u
#define DAC_WAIT_REQUIRED_US            2
#define DAC_WAIT_DELAY_CPU_CYCLES       (uint16_t)(DAC_WAIT_REQUIRED_NS/ONE_CPU_CLOCK_CYCLE_NS)
#define DAC_WAIT_COUNT                  ((SYSTEM_CLOCK_MHZ * DAC_WAIT_REQUIRED_US)+1)/(NUM_NOP_INSTRUCTIONS +5)

/** API defines*/
/**
 * \brief Initialization routine for DAC Module
 * \description DAC Module resiters are initialized and enabled ready for conversion
 * param[in] void
 * return DAC Initialization return
 */
eDAC_INIT_RETURN DAC_Initialization (void);

/**
 * \brief De-initialize DAC
 * \description This routine disables the DAC module and Resets the registers
 * param[in] void
 */
void DAC_SynchronousWrite(UINT16 digitalSampleValue);

/**
 * \brief DAC conversion routine
 *
 * param[in] u16digitalSampleValue = Analog_voltage * 1023 / Vref
 */
void DAC_Deinitialization(void);

/**
 * \brief Initialization routine for DAC Module
 * \description DAC Module resiters are initialized and enabled ready for conversion
 *  param[in] void
 *  return DAC Initialization return
*/
UINT16 DAC_DriveVoltage(UINT16 u16ExpctdVoltageLevel);
/**
 * \brief Disbale DAC Module
 * \description This routine disables the DAC module
 * param[in] void
 */
void DAC_Disable(void);
void DAC_Reconfigure(double adc_value_calb);
UINT16 DAC_ValueRound(double x);
void DAC_CalibrateStepResolution(double dActualVoltageLevel,UINT16 u16DrivenSampleSteps);



#endif
