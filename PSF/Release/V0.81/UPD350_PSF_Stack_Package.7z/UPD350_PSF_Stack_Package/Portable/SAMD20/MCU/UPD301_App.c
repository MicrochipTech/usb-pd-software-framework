/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include "stdinc.h"
#include <UPD301_App.h>
#include "SERCOM_I2CSlave.h"
#include "Interrupts.h"
#include "Timers.h"


static UINT32 gu32CriticalSectionCnt = SET_TO_ZERO;

void* UPD301_MemCpy(void *dest, const void *src, int n)
{
   // Typecast src and dest addresses to (char *)
   char *csrc = (char *)src;
   char *cdest = (char *)dest;
 
   // Copy contents of src[] to dest[]
   for (int i=0; i<n; i++)
       cdest[i] = csrc[i];
   
   return dest;
}

int UPD301_MemCmp(const void *pau8Data1, const void *pau8Data2, int len)
{
	int i;
    UINT8 *pu8Obj1 = (UINT8 *)pau8Data2;
    UINT8 *pu8Obj2 = (UINT8 *)pau8Data2;
	
	for (i = 0; i < len; i++)
    {
    	if (pu8Obj1[i] != pu8Obj2[i])
            return (pu8Obj1[i] - pu8Obj2[i]);            	
	}
    
	return 0;
}


void PDStack_Events(UINT8 u8PortNum, UINT8 u8PDEvent)
{
    if((TYPEC_ATTACHED_SRC_DRIVE_PWR_EVENT == u8PDEvent) || (TYPEC_SNK_CURRENT_LIMIT_EVENT == u8PDEvent))
    {
    }
    else if(TYPEC_DETACH_EVENT == u8PDEvent)
    {
        /*Set tristate for detach event*/
        if(0 == u8PortNum)
        {
            GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_IN);
            GPIO_SetPullMode(PIN_PA28,GPIO_PULLOFF); 
            GPIOStrap_SetTristate(PIN_PA28);
        }
        else
        {
             UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_DISABLE_GPIO);
        }
    
    }
    else if((TYPEC_CC2_ORIENTATION == u8PDEvent))
    {
        /*Drive Low for CC2 Orientation*/
        if(0 == u8PortNum)
        {
            GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVELOW);
        }
        else
        {
            UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_ENABLE_GPIO);
            UPD_GPIOSetDirection(1,UPD_PIO2,UPD_GPIO_SETDIR_OUTPUT);
            UPD_GPIOSetBufferType(1,UPD_PIO2,UPD_GPIO_SETBUF_PUSHPULL);
            UPD_GPIOSetClearOutput(1,UPD_PIO2,UPD_GPIO_CLEAR);
        }          
    }
    else if(TYPEC_CC1_ORIENTATION == u8PDEvent)
    {
        /*Drive High for CC1 Orientation*/
        if(0 == u8PortNum)
        {
            GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVEHIGH);
        }
        else
        {
            UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_ENABLE_GPIO);
            UPD_GPIOSetDirection(1,UPD_PIO2,UPD_GPIO_SETDIR_OUTPUT);
            UPD_GPIOSetBufferType(1,UPD_PIO2,UPD_GPIO_SETBUF_PUSHPULL);
            UPD_GPIOSetClearOutput(1,UPD_PIO2,UPD_GPIO_SET);
        }    
    }
}
/**************************************************************/
#if INCLUDE_POWER_FAULT_HANDLING

UINT8 UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts)
{
  	return DPM_HANDLE_PWR_FAULT;
}

					 
#endif /*INCLUDE_POWER_FAULT_HANDLING*/
/*******************************************************************************/

#if INCLUDE_POWER_MANAGEMENT_CTRL
void SetMCUIdle()
{
    /*gu8SetMCUidle was set as UPD_MCU_IDLE by Zeus Stack,
    but lets verify whether we can go to idle, otherwise return from here*/
    if (FALSE == UPD_CheckUPDsActive())
    {     
        /*If current power role is source for port0 and if type-c is attached which
        sourcing more than 0v then ADC is running to monitor VDD33. so FW cant go to idle,
        so return from here*/
        if ((DPM_GET_CURRENT_POWER_ROLE (0) == PD_ROLE_SOURCE) && 
            (DPM_GetVBUSVoltage(0) > PWRCTRL_VBUS_0V))
        {
            gu8SetMCUidle = UPD_MCU_ACTIVE;
            return;
        }
    }
 
    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
    
	/*Set NVIC SERCOM1 Interrupt before going to sleep for wake up*/    
    REGDW(NVIC_BASE_ADDR) |= INT_NVIC_SERCOM1;
    
    /*Enable Address Match to wake up from MCU Idle*/  
    REGB(I2C_SLAVE_INTENSET) |= I2C_SLAVE_INTFLAG_AMATCH;
    
    /*Disable Timer to avoid interrupt from Timer*/
    REGB(TC0_CTRLA) &= ~TC0_CTRLA_ENABLE; 
    
    HOOK_DEBUG_PORT_STR (3, "UPD301: Set UPD301 IDLE");
    
	/*If there is any pending interrupt it will not go to sleep*/
    SCB->SCR |=  (SCB_SCR_SLEEPDEEP_Msk )| (SCB_SCR_SEVONPEND_Msk);
    
    __DSB();
    __WFI();
    
    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();

}
      
void MCUResumeFromIdle()
{
     REGB(TC0_CTRLA) |= TC0_CTRLA_ENABLE;
}

#endif


void Reset_UPD350_Thru_MCU_GPIO(UINT8 u8PortNum)
{
    if (0 == u8PortNum)
    {
        /* Reset the UPD350 for enabled ports */
        GPIO_SetDirection(CONFIG_SOC_UPDRESET_ROUTING,    GPIO_SETDIRECTION_IN);
        GPIO_SetPullMode(CONFIG_SOC_UPDRESET_ROUTING,    GPIO_PULLDOWN);

        /*Delay */
        for(UINT16 u16delayloop = 0u; u16delayloop <(6000);u16delayloop++)
        {
            __asm volatile("nop");
            __asm volatile("nop");

        }

        GPIO_SetPullMode(CONFIG_SOC_UPDRESET_ROUTING, GPIO_PULLOFF);
    }
}



void UPDIntr_EnterCriticalSection(volatile hal_atomic_t* pCrtSecObj)
{
    if (gu32CriticalSectionCnt++ == 0)  
    {
        /*Interrupt is disabled if Critical section is not entered already*/
		CRITICAL_SECTION_ENTER(pCrtSecObj);
    }
}

void UPDIntr_ExitCriticalSection(volatile hal_atomic_t* pCrtSecObj)
{
    
    if (--gu32CriticalSectionCnt == 0)
    {
        /*Interrupt is Eanbled when there is no pending critical section nesting*/
		CRITICAL_SECTION_LEAVE(pCrtSecObj);
    }
}



