/*******************************************************************************
Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#include <stdinc.h>

/*******************************************************************/
/******************* Functions**************************************/
/*******************************************************************/


void PD_CheckAndDisablePorts ()
{
    UINT8 u8ReadData[4];
    
    /*variable to hold the timer id*/
    UINT8 u8TimerID;
    
    /*run a loop for all the number of CONFIG_PD_PORT_COUNT to check all ports*/
    for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
    {
        /* Reset the Port's UPD350 present*/
        CONFIG_HOOK_UPDRESET_THRU_GPIO(u8PortNum);
        
        /*Start 10ms timer*/
        u8TimerID = PDTimer_Start (MILLISECONDS_TO_TICKS(10), NULL, (UINT8)SET_TO_ZERO, (UINT8)SET_TO_ZERO);
        /*Check if timer is Active, if Timer expired, come out of this loop and go ahead with the status of 
          gau8PortDisable[u8PortNum]*/
        while ((gasPDTimers[u8TimerID].u8TimerSt_PortNum & GENERIC_TIMER_STATE) != GENERIC_TIMER_EXPIRED)
        {
            /*u8IsSPI_CommActive[u8PortNum] default value is FALSE*/
            if (gau8PortDisable[u8PortNum] == PORT_STATUS_DISABLED)
            {
                /*Read SPI_TEST register*/
                UPD_RegisterRead(u8PortNum, (UINT16)UPD_SPI_TEST, u8ReadData, 4);
                    
                /*Check the SPI_TEST register value is 0x02*/
                if (u8ReadData[0] == UPD_SPI_TEST_VAL)
                {
                    /*Read VID & PID register*/
                    UPD_RegisterRead(u8PortNum, (UINT16)UPD_VID, u8ReadData, 4);          
             
                    /*Verify the default values*/
                    if((u8ReadData[0] == UPD_VID_LSB) && (u8ReadData[1] == UPD_VID_MSB) && \
                      (u8ReadData[2] == UPD_PID_LSB) && (u8ReadData[3] == UPD_PID_MSB))
                    {  
                        /*Value read from this port is right, so enable the ports, Set SPI 
                           Communcation is active for this port*/
                        gau8PortDisable[u8PortNum] = PORT_STATUS_ENABLED;
                        break;
                    }
                }
            }
        }
        /*kill the timer if the UPD is identified.*/
        PDTimer_Kill (u8TimerID);
    }
    
    /* Work around - If port-0 as source and port-1 as sink interrupt issued continuously */
    for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
  	{
        if (PORT_STATUS_DISABLED == gau8PortDisable[u8PortNum])
        {
            gasPortConfigurationData[u8PortNum].u32CfgData = 0;
        }
    }
}


void PD_StateMachinesInit()
{
	for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
  	{
        
        if (PORT_STATUS_ENABLED == gau8PortDisable[u8PortNum])
        {
		  	/* Init UPD350 GPIO */
		  	UPD_GPIOInit(u8PortNum);
			
            /*Type-C UPD350 register configuration for a port*/
            TypeC_InitPort(u8PortNum);
            
            /* PRL Init for all the port present */
            PRL_Init (u8PortNum);
        }
    }
}

void PD_FindVBusCorrectionFactor()
{
    UINT16 u16VBUSTHR3 = 0;
      
    for(UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
    {
        if (gau8PortDisable[u8PortNum] == PORT_STATUS_ENABLED)
        {
            /* Read VBUS threshold register value from OTP */    
            u16VBUSTHR3 = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR3);
            
            gasTypeCcontrol[u8PortNum].fVBUSCorrectionFactor = \
                                    (float)((float)u16VBUSTHR3/(float)222);
        }
    }
        
     
}

UINT8 PSF_Init(void)
{
    UINT8 u8InitStatus = 1;
       
    /*Timer module Initialization*/
    (void)PDTimer_Init();
    
    /*Initialize HW SPI module defined by the user*/
    CONFIG_HOOK_UPD_HW_INTF_INIT();
    
    for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
    {
        /*UPD350 Reset GPIO Init*/
        CONFIG_HOOK_HW_UPDRESETGPIO_INIT(u8PortNum);
    }
        
    /*Initialize config global variables*/
    PD_InitializeConfigGlobals();
	
	/*Initialize Internal global variables*/
    PD_InitializeInternalGlobals();
    
    PD_CheckAndDisablePorts();
    
    CONFIG_HOOK_PORTS_ENABLE_DISABLE(&gau8PortDisable[0],&gasPortConfigurationData[0]);
    
    /* VBUS threshold correction factor */
    PD_FindVBusCorrectionFactor();
    
    /*Initialize debug hardware*/
    CONFIG_HOOK_DEBUG_INIT();
    
    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
    
    CONFIG_HOOK_GPIO_INT_HW_INIT();
    
    for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
    {
        if (PORT_STATUS_ENABLED == gau8PortDisable[u8PortNum])
        {
            /*User defined UPD Interrupt Initialization for MCU*/
            CONFIG_HOOK_HW_UPDALERTGPIO_INIT(u8PortNum);
            
            /*Port Power Intialisation*/
            CONFIG_HOOK_HW_PORTPWR_INIT(u8PortNum);
        }
    }
	    
    PD_StateMachinesInit();  

    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
    
    return u8InitStatus;

}

void PSF_RUN()
{
	for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
  	{
          if (PORT_STATUS_ENABLED == gau8PortDisable[u8PortNum])
          {
             DPM_StateMachine (u8PortNum);
              
			#if INCLUDE_POWER_MANAGEMENT_CTRL
                

            /*Restart IDLE Timer if UPD350 is Active*/
            PD_StartIdleTimer (u8PortNum);

            if (gu8SetMCUidle)
            {
                /*Invalidate MCU Idle*/
                gu8SetMCUidle = UPD_MCU_ACTIVE;      

                CONFIG_HOOK_SET_MCU_IDLE();

                CONFIG_HOOK_MCU_RESUME_FROM_IDLE();

            }
                
              
			#endif
      
          }
	}
}

