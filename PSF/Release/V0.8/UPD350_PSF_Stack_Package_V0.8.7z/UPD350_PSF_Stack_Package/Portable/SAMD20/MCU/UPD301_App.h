/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _UPD301_APP_H_
#define _UPD301_APP_H_

#include <hal_atomic.h>
#include <dac.h>

/* define PORT*/

#define PORT0 		0
#define PORT1		1
#define PORT2       2
#define PORT3 		3






#define UPD301_ENTER_CRITICAL()      {\
                                        volatile hal_atomic_t CrtSecObj;\
                                        UPDIntr_EnterCriticalSection(&CrtSecObj);
#define UPD301_EXIT_CRITICAL()      UPDIntr_ExitCriticalSection(&CrtSecObj); \
                                     }
void UPDIntr_EnterCriticalSection(volatile hal_atomic_t*);
void UPDIntr_ExitCriticalSection(volatile hal_atomic_t*);

void PDStack_Events(UINT8 u8PortNum, UINT8 u8PDEvent);

void* UPD301_MemCpy(void *dest, const void *src, int n);
int UPD301_MemCmp(const void *pau8Data1, const void *pau8Data2, int len);
void GPIOStrap_SetTristate(UINT8 u8pin);
UINT8 GPIOStrap_GetInputLevel(UINT8 u8pin);


UINT8 UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts);

void SetMCUIdle();
void MCUResumeFromIdle();
UINT8 DCDCSel_StrapDecode(void);
/* UPD350 Reset function */
void Reset_UPD350_Thru_MCU_GPIO(UINT8 u8PortNum);

//void  UPD301_SinkCurrentControl(UINT8 u8PortNum, UINT16 u16ReqCurrent);

#endif