
#include <hal_atomic.h>
#include <stdinc.h>
#include <Interrupts.h>


void main()
{
   
    MCU_Init();

    (void)PSF_Init();
    
    while(TRUE)
    {   
        PSF_RUN();
        
    }

}
