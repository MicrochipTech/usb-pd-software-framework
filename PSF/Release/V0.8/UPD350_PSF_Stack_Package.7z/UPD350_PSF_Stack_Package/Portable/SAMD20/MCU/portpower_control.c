/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/


#include <stdinc.h>
#include <portpower_control.h>
#include <dac.h>

static void UPD_GPIOGeneric(UINT8 u8PortNum,UINT8 u8PIONum);
static void UPD_GPIOGenericOutputInit(UINT8 u8PortNum,UINT8 u8PIONum, UINT8 u8PioMode);

static void UPD_GPIOGeneric(UINT8 u8PortNum,UINT8 u8PIONum)
{
    UPD_GPIOEnableDisable(u8PortNum,u8PIONum,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(u8PortNum,u8PIONum,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(u8PortNum,u8PIONum,UPD_GPIO_SETBUF_PUSHPULL);
}
static void UPD_GPIOGenericOutputInit(UINT8 u8PortNum,UINT8 u8PIONum, UINT8 u8PioMode)
{
    if (UPD_PIO_UN_DEF != u8PIONum)
    {
        /*clear bits 6:4 and 1:0 in the read value to avoid invalid combinations.*/
        u8PioMode &= (UPD_GPIO_PULL_UP_ENABLE | UPD_GPIO_DATAOUTPUT | UPD_GPIO_BUFFER);
        /*enable GPIO and direction as output*/
        u8PioMode |= (UPD_GPIO_DIRECTION | UPD_GPIO_ENABLE);
        /*de-assert the pin*/
        u8PioMode ^= UPD_GPIO_DATAOUTPUT;
        /*update the value to GPIO register.*/
        UPD_GPIORegisterUpdate(u8PortNum, u8PIONum, u8PioMode);
    }
}

void PWRCTRL_initialization(UINT8* pu8PortEnDis)
{
    if(PORT_STATUS_ENABLED == pu8PortEnDis[PORT0])
    {
        UPD_GPIOGenericOutputInit(PORT0, gasUpdPioConfigData[PORT0].u8VBUSDisPio, \
                                        gasUpdPioConfigData[PORT0].u8VBUSDisPioMode);

        UPD_GPIOGenericOutputInit(PORT0, gasUpdPioConfigData[PORT0].u8VBUSEnPio, \
                                        gasUpdPioConfigData[PORT0].u8VBUSEnPioMode);
        
        //if(DCDC_RESERVED != gu8Port0DCDCSelType)
        {
            (void)DAC_Initialization();
        }
    }

    if(PORT_STATUS_ENABLED == pu8PortEnDis[PORT1])
    {
        UPD_GPIOGenericOutputInit(PORT1, gasUpdPioConfigData[PORT1].u8DcDcEnPio, \
                                        gasUpdPioConfigData[PORT1].u8DcDcEnPioMode);

        UPD_GPIOGenericOutputInit(PORT1, gasUpdPioConfigData[PORT1].u8VBUSEnPio, \
                                        gasUpdPioConfigData[PORT1].u8VBUSEnPioMode);

        UPD_GPIOGenericOutputInit(PORT1, gasUpdPioConfigData[PORT1].u8VBUSDisPio, \
                                        gasUpdPioConfigData[PORT1].u8VBUSDisPioMode);
        
        UPD_GPIOGenericOutputInit(PORT1, gasUpdPioConfigData[PORT1].u8VSEL0Pio, \
                                        gasUpdPioConfigData[PORT1].u8VSEL0PioMode);
        
        UPD_GPIOGenericOutputInit(PORT1, gasUpdPioConfigData[PORT1].u8VSEL1Pio, \
                                        gasUpdPioConfigData[PORT1].u8VSEL1PioMode);
        
        UPD_GPIOGenericOutputInit(PORT1, gasUpdPioConfigData[PORT1].u8VSEL2Pio, \
                                        gasUpdPioConfigData[PORT1].u8VSEL2PioMode);
        
        UPD_GPIOUpdateOutput(PORT1, gasUpdPioConfigData[PORT1].u8DcDcEnPio, \
                gasUpdPioConfigData[PORT1].u8DcDcEnPioMode, UPD_GPIO_ASSERT);
    }

}


void PWRCTRL_SetPortPower (UINT8 u8PortNum, UINT16 u16VBUSVoltage, UINT16 u16Current)
{
    UINT8 u8EnVbusMode;
    u8EnVbusMode = gasUpdPioConfigData[u8PortNum].u8VBUSEnPioMode;
    if ((PWRCTRL_VBUS_0V == u16VBUSVoltage) || \
                (!(UPD_RegReadWord (u8PortNum, UPD_PIO_STS) & \
                                BIT(gasUpdPioConfigData[u8PortNum].u8FaultInPio))))
    {
        /*Drive EN_VBUS low when driving VBUS zero*/
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, u8EnVbusMode, UPD_GPIO_DE_ASSERT);
    }
    else
    {
        /*Drive EN_VBUS high when driving VBUS high*/
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, u8EnVbusMode, UPD_GPIO_ASSERT);
    }

    if(PORT0 == u8PortNum)
    {
        (void)DAC_DriveVoltage(u16VBUSVoltage);
    }

    else if (1 == u8PortNum)
    {
        switch (u16VBUSVoltage)
        {
            case PWRCTRL_VBUS_0V:
            {

                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode, UPD_GPIO_DE_ASSERT);
                
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode, UPD_GPIO_DE_ASSERT);
                
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode, UPD_GPIO_DE_ASSERT);
                
                break;
            }

            case PWRCTRL_VBUS_5V:
            {

                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode, UPD_GPIO_DE_ASSERT);
                
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode, UPD_GPIO_DE_ASSERT);
                
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode, UPD_GPIO_DE_ASSERT);

                break;
            }

            case PWRCTRL_VBUS_9V:
            {

                /*Setting PWRCTRL_ENABLE_9V_EU */
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode, UPD_GPIO_ASSERT);

                 /*Resetting PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode, UPD_GPIO_DE_ASSERT);
                
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode, UPD_GPIO_DE_ASSERT);

                break;
            }

            case PWRCTRL_VBUS_15V:
            {

                /*Setting PWRCTRL_ENABLE_15V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode, UPD_GPIO_ASSERT);
                
                 /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode, UPD_GPIO_DE_ASSERT);

                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode, UPD_GPIO_DE_ASSERT);

                break;
            }

            case PWRCTRL_VBUS_20V:
            {
                /*Setting PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL2Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL2PioMode, UPD_GPIO_ASSERT);
                
                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU*/
                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL0Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL0PioMode, UPD_GPIO_DE_ASSERT);

                UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSEL1Pio, \
                        gasUpdPioConfigData[u8PortNum].u8VSEL1PioMode, UPD_GPIO_DE_ASSERT);

                break;
            }

            default:
            break;
        }
    }
}

void PWRCTRL_ConfigVBUSDischarge (UINT8 u8PortNum, UINT8 u8EnaDisVBUSDIS)
{
    UINT8 u8VbusDisMode = gasUpdPioConfigData[u8PortNum].u8VBUSDisPioMode;
    
    if (u8EnaDisVBUSDIS == PWRCTRL_ENABLE_VBUSDIS )
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, u8VbusDisMode, UPD_GPIO_ASSERT);
    }
    else
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, u8VbusDisMode, UPD_GPIO_DE_ASSERT);
    }

}


