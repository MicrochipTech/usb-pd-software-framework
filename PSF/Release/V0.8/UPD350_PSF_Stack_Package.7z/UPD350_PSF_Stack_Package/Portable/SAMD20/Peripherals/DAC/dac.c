/*
	dac.c

	File Description
	This file contains API definitions for DAC module

	Copyright(C) 2018, Microchip Technology Inc. All Rights Reserved.

	This program code listing is proprietary to Microchip and may not be copied,  
	distributed, or used without a license to do so. Such license may have  
	Limited or Restricted Rights. Please refer to the license for further clarification.

	THIS SOFTWARE IS PROVIDED IN AN ?AS IS? CONDITION. NO WARRANTIES,
	WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
	TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
	PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
	IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
	CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*/

#include <stdinc.h>
//#include <math.h>
#include <dac.h>
#include "GPIO.h"
#include "REG_SAMD20.h"

/**For initial value assume that the 0.61v is driven exactly when DAC_PDPM_5V_DIGITAL_SAMPLE is written to DAC*/
static volatile double gdStepResolution = (DAC_PDPM_5V_STEP / DAC_PDPM_5V_DIGITAL_SAMPLE);
/**
 * \brief Initialization routine for DAC Module
 * \description DAC Module resiters are initialized and enabled ready for conversion
 * param[in] void
 * return DAC Initialization return
 */
eDAC_INIT_RETURN DAC_Initialization (void)
{
    /**1) Peripheral clock mask of the DAC Module is unmasked.*/
    
    /* Select AHBC bus clk for DAC module*/
    UINT32 u32Peripheral = (DAC_BASE_ADDRESS & 0x0000ff00uL) >> 10u;    
    REGDW(PM_APBCMASK_REG) |= (1u << u32Peripheral);
    
    /* Select Generater0 and set CLK enable bit*/
    REGW(GCLK_CLKCTRL_REG) = (CLKCTRL_ID(DAC_GCLK_INDEX) | CLKCTRL_GEN(CLKCTRL_GEN_GCLK0_Val) | (CLKCTRL_CLKEN));
   
    /**3) Wait for DAC module Interface clock and GCLK to synchronize.**/
    DAC_WAIT_FOR_SYNC();

    /**4) check the ENABLE field in the DAC CNTRLA register to verify if the
            module has already been enabled*/
    if (DAC_CNTRLA_ISENABLE()) {
    /**Already DAC Module is in Enabled state*/
            return eDAC_INIT_ERROR;
    }
    /**5) Assert the SWRST field in the CNTRLA register*/
    DAC_MODULE_RESET();
    /**6) Wait for DAC module Interface clock and GCLK to synchronize**/
    DAC_WAIT_FOR_SYNC();
    
    /**7) REFSEL field is = 0x2 => VREFP External reference
    EOEN � 0x01 => External DAC Output to Vout pin is enabled.*/
    REGB(DAC_BASE_ADDRESS +DAC_CTRLB_ADDROFFSET) = 
      (UINT8)(DAC_CTRLB_B_EOEN | 
       (UINT8)( /*eDAC_REFSEL_VREFPIN*/(UINT8)eDAC_REFSEL_ANALOGVCC << DAC_CTRLB_START_REFSEL));
    
    /**8) Enable the DAC module*/
    //REGB(DAC_BASE_ADDRESS +DAC_CTRLA_ADDROFFSET) =  DAC_CNTRLA_B_ENABLE;
    /**PA02 is DAC Vout pin*/
    GPIO_SetDirection(PIN_PA02, GPIO_SETDIRECTION_OFF);

    GPIO_SetPinFunction(PIN_PA02, MUX_PA02B_DAC_VOUT);
    /**PA03 is DAC Vref pin*/
/*    GPIO_SetDirection(PIN_PA03, GPIO_SETDIRECTION_OFF);
    
    GPIO_SetPinFunction(PIN_PA03, MUX_PA03B_DAC_VREFP);*/ /**Removing the VREF PIN configuration as Internal
Reference is to be used*/
   
    //DAC_DriveVoltage(PWRCTRL_VBUS_5V);
    
    //DAC_DriveVoltage(PWRCTRL_VBUS_0V);
    
   DAC_CalibrateStepResolution((float)(3.3), 0x3FF);
    
    /**DAC initialization completed*/
    return eDAC_INIT_SUCCESS;
}

/**
 * \brief De-initialize DAC
 * \description This routine disables the DAC module and Resets the registers
 * param[in] void
 */
void DAC_Deinitialization(void)
{
  DAC_WAIT_FOR_SYNC();
  /**Reset the Enable DAC field*/
  REGB(DAC_BASE_ADDRESS +DAC_CTRLA_ADDROFFSET) &=  (~DAC_CNTRLA_B_ENABLE);
  /**Soft Reset of DAC Module*/
  DAC_MODULE_RESET();

}

/**
 * \brief Disbale DAC Module
 * \description This routine disables the DAC module
 * param[in] void
 */
void DAC_Disable(void)
{
  DAC_WAIT_FOR_SYNC();
  /**Reset the Enable DAC field*/
  REGB(DAC_BASE_ADDRESS +DAC_CTRLA_ADDROFFSET) &=  (~DAC_CNTRLA_B_ENABLE);
}

/**
 * \brief DAC conversion routine
 *
 * param[in] u16digitalSampleValue = Analog_voltage * 1023 / Vref
 */
void DAC_SynchronousWrite(UINT16 u16digitalSampleValue)
{
    UINT16 u16delayloop;
    
    DAC_WAIT_FOR_SYNC();
    /**Write the 10bit sample value to the DATA register*/
    REGW(DAC_BASE_ADDRESS + DAC_DATA_ADDROFFSET) = u16digitalSampleValue;
    
    /**1) Wait for DAC module Interface clock and GCLK to synchronize**/     
    DAC_WAIT_FOR_SYNC();
    /**Enable the DAC Module*/
    REGB(DAC_BASE_ADDRESS + DAC_CTRLA_ADDROFFSET) =  (DAC_CNTRLA_B_ENABLE|DAC_CNTRLA_B_RUNSTDBY);      
    
    /**Blocking wait for DAC Conversion time of 2.85us*/
    /**
    Test Code
    gpio_set_pin_direction(PA24, GPIO_DIRECTION_OUT);
    gpio_set_pin_level(PA24,true);
    **/
    
    /**Delay for 2.85us, to prevent DAC data register overwrite before conversion*/
    for(u16delayloop = 0u; u16delayloop <(DAC_WAIT_COUNT);u16delayloop++)
    {
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
        __asm volatile("nop");
    }
    /**
    Test Code      
    gpio_set_pin_level(PA24,false);
    **/
}



UINT16 DAC_DriveVoltage(UINT16 u16ExpctdVoltageLevel)
{
    UINT16 u16DacSteps = 0x00u;
    UINT8 u8IsValidConversion = TRUE;
    
    //if(DCDC_LINEAR_DAC_TYPE == gu8Port0DCDCSelType)
    {
        switch(u16ExpctdVoltageLevel)
        {
            case PWRCTRL_VBUS_0V:
            {
                DAC_Disable();
                u8IsValidConversion = FALSE;
                break;
            }
            case PWRCTRL_VBUS_5V:
            {
                //fCurrentVref = (fStepResolution * 0x3FF);
                u16DacSteps = DAC_ValueRound(DAC_PDPM_5V_STEP / gdStepResolution);
                break;
            }
            case PWRCTRL_VBUS_9V:
            {
                u16DacSteps = DAC_ValueRound(DAC_PDPM_9V_STEP / gdStepResolution);
                break;
            }
            case PWRCTRL_VBUS_15V:
            {
                u16DacSteps = DAC_ValueRound(DAC_PDPM_15V_STEP / gdStepResolution);
                break;
            }
            case PWRCTRL_VBUS_20V:
            {
                u16DacSteps = DAC_ValueRound(DAC_PDPM_20V_STEP / gdStepResolution);
                break;
            }
            default:
            {
              /** Retain the previous value */
              u8IsValidConversion = FALSE;
              break;
            }

        }

        /** Check if the requested voltage is valid */
        if(FALSE != u8IsValidConversion)
        {
          DAC_SynchronousWrite(u16DacSteps);
        }
        else
        {
          /* No DAC operation */
        }
    }
    return u16DacSteps;
}


void DAC_CalibrateStepResolution(double dActualVoltageLevel,UINT16 u16DrivenSampleSteps)
{
    gdStepResolution = dActualVoltageLevel / u16DrivenSampleSteps;
}


void DAC_Reconfigure(double adc_value_calb)
{
    UINT16 u16CurrentVoltageLevel;

    u16CurrentVoltageLevel = DPM_GetVBUSVoltage(0);    
    
    if (u16CurrentVoltageLevel > PWRCTRL_VBUS_0V)
    {
        DAC_CalibrateStepResolution((float)adc_value_calb, 0x3FF);
        (void)DAC_DriveVoltage(u16CurrentVoltageLevel);    
    }
}


UINT16 DAC_ValueRound(double x)
{
    float b;
    int a = (int)x;
    b = x-a;
    
    if (b >= 0.5)
    {
        return a+1;
    }
    
    else
    {
        return a;
    }
    
}
