/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include "SERCOM_Spi.h"

/******************************************************************************
 * Function:        void SPI_ChipSelectLow (UINT8 u8Portnum)
 * Input:           Buffer pointer and Read length
 * Output:          nothing					
 * Overview:        This routine do chip select signal low for UPD350 	
 * Note:            This read is done by status bit polling mode
 *****************************************************************************/
void SPI_ChipSelectLow(
    UINT8   u8Portnum)  /* */
{
    if(u8Portnum == 0)
    {
        GPIO_SetPinLevel((UINT8) PIN_PA10, FALSE);
    }

    if(u8Portnum == 1)
    {
        GPIO_SetPinLevel((UINT8) PIN_PA01, FALSE);
    }
}

/******************************************************************************
 * Function:        void SPI_ChipSelectHigh (UINT8 u8Portnum)
 * Input:           Buffer pointer and Read length
 * Output:          nothing					
 * Overview:        This routine do chip select signal High for UPD350 	
 * Note:            This read is done by status bit polling mode
 *****************************************************************************/
void SPI_ChipSelectHigh(
    UINT8   u8Portnum)  /* */
{
    if(u8Portnum == 0)
    {
        GPIO_SetPinLevel((UINT8) PIN_PA10, TRUE);
    }

    if(u8Portnum == 1)
    {
        GPIO_SetPinLevel((UINT8) PIN_PA01, TRUE);
    }
}

/******************************************************************************
 * Function:        void SPI_Write (UINT8 u8PortNum,UINT8 *pu8WriteBuffer, UINT16 u16Writelength)
 * Input:           Buffer pointer and Read length
 * Output:          nothing					
 * Overview:        This routine write UPD register bytes and one byte is written for every access 	
 * Note:            This read is done by status bit polling mode
 *****************************************************************************/
void SPI_Write(
    UINT8   u8PortNum,
    UINT8   *pu8WriteBuffer,    /* */
    UINT16  u16Writelength)     /* */
{
    UINT8 volatile  u8tempbuff = 0;
    for(UINT16 u16Txcount = 0; u16Txcount < u16Writelength; u16Txcount++)
    {
        /*Wait till data register to empty*/
        while((REGB(SERCOMSPI_INTFLAG) & SERCOMSPI_INTFLAG_DRE) == 0);

        /* Write buffer data bytes to DATA register*/
        REGB(SERCOMSPI_DATA) = pu8WriteBuffer[u16Txcount];

        /* Wait till Receive interuupt occurs*/
        while((REGB(SERCOMSPI_INTFLAG) & SERCOMSPI_INTFLAG_TXC) == 0);

        /* Write DATA register to temp buffer to empty shift register*/
        u8tempbuff = REGB(SERCOMSPI_DATA);

        /* Clear Transmit intruppt*/
        REGB(SERCOMSPI_INTFLAG) &= ~SERCOMSPI_INTFLAG_TXC;
    }
}

/******************************************************************************
 * Function:        void SPI_Read (UIN8 u8PortNum, UINT8 *pu8ReadBuffer, UINT16 u16Readlength)
 * Input:           Buffer pointer and Read length
 * Output:          nothing					
 * Overview:        This routine read UPD register bytes and one byte is read for every access
 * Note:            This read is done by status bit polling mode
 *****************************************************************************/
void SPI_Read(
    UINT8   u8PortNum,
    UINT8   *pu8ReadBuffer, /* */
    UINT16  u16Readlength)  /* */
{
    for(UINT16 u16Rxcount = 0; u16Rxcount < u16Readlength; u16Rxcount++)
    {
        /*Wait till data register to empty*/
        while((REGB(SERCOMSPI_INTFLAG) & SERCOMSPI_INTFLAG_DRE) == 0);

        /* Write dummy bytes to DATA register*/
        REGB(SERCOMSPI_DATA) = DUMMYBYTE;

        /* Wait till Receive interuupt occurs*/
        while((REGB(SERCOMSPI_INTFLAG) & SERCOMSPI_INTFLAG_RXC) == 0);

        /* Copy DATA register to application buffer*/
        pu8ReadBuffer[u16Rxcount] = REGB(SERCOMSPI_DATA);

        /* Clear Receive intruppt*/
        REGB(SERCOMSPI_INTFLAG) &= ~SERCOMSPI_INTFLAG_RXC;
    }
}

/******************************************************************************
 * Function:        void SPI_SyncEnable(void)
 * Input:           None
 * Output:          Function return TRUE If SPI enabled successfully					
 * Overview:        This routine enables SPI module 
 * Note:            before setting Enable bit ensure that SYNCBUSY bit not set
 *****************************************************************************/
void SPI_SyncEnable(void)
{
    REGDW(SERCOMSPI_CTRLA) |= CTRLA_ENABLE;

    /* Wait Until SYNCBUSY bit to clear*/
    while((REGW(SERCOMSPI_STATUS)) & STATUS_SYNCBUSY);
}

/******************************************************************************
 * Function:        void SPI_PortInit (void)
 * Input:           None
 * Output:          none					
 * Overview:        This routine initialize SPI SERCOM pad 
 * Note:            SERCOM pads configured as per die revision C and E
 *****************************************************************************/
void SPI_PortInit(void)
{
    /* Set PA11 pin direction to Output - MOSI*/
    GPIO_SetDirection(PIN_PA11, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(PIN_PA11, GPIO_DRIVEHIGH);
    GPIO_SetPinFunction(PIN_PA11, MUX_PA11C_SERCOM0_PAD3);

    /* Set PA09 pin direction to output - CLK*/
    GPIO_SetDirection(PIN_PA09, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(PIN_PA09, GPIO_DRIVELOW);
    GPIO_SetPinFunction(PIN_PA09, MUX_PA09C_SERCOM0_PAD1);

    /* Set PA10 pin direction to output - SPI CS*/
    GPIO_SetDirection(PIN_PA10, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(PIN_PA10, GPIO_DRIVEHIGH);
    GPIO_SetPinFunction(PIN_PA10, GPIO_PIN_FUNC_OFF);

    /* Set PA08 pin direction to Input - MISO*/
    GPIO_SetDirection(PIN_PA08, GPIO_SETDIRECTION_IN);
    GPIO_SetPullMode(PIN_PA08, GPIO_PULLOFF);
    GPIO_SetPinFunction(PIN_PA08, MUX_PA08C_SERCOM0_PAD0);

    /*Setting the pin PA02 as Chip select for external UPD350*/
    GPIO_SetDirection(PIN_PA01, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(PIN_PA01, GPIO_DRIVEHIGH);
    GPIO_SetPinFunction(PIN_PA01, GPIO_PIN_FUNC_OFF);
}

/******************************************************************************
 * Function:        void SPI_SyncInit (void)
 * Input:           None
 * Output:          Function return TRUE If SPI registers configured successfully					
 * Overview:        This routine configures SPI registers				
 * Note:            
 *****************************************************************************/
void SPI_SyncInit(void)
{
    /* Set to SPI in Master mode */
    REGB(SERCOMSPI_CTRLA) = (SPI_MASTER_MODE);

    /* SPI Input mux selection*/
    REGDW(SERCOMSPI_CTRLA) |= CTRLA_DIPO(0x00); /* As per DOS*/

    /* SPI Input mux selection*/
    REGDW(SERCOMSPI_CTRLA) |= CTRLA_DOPO(0x02); /* As per DOS*/

    /* SPI enable*/
    REGDW(SERCOMSPI_CTRLB) |= CTRLB_RXEN;

    /*SPI Baud rate set to 8 MHz(0x02) and for 12 MHz(0x01) */
    REGB(SERCOMSPI_BAUD) |= 0x02;

    /* Wait Until SYNCBUSY bit to clear*/
    while((REGW(SERCOMSPI_STATUS)) & STATUS_SYNCBUSY);
}

/******************************************************************************
 * Function:        void SPI_ClkInit (void)
 * Input:           None
 * Output:          Function return TRUE If SPI CLK configured successfully					
 * Overview:        This routine configures GCLK module to clock SERCOM				
 * Note:            
 *****************************************************************************/
void SPI_ClkInit(void)
{
    /* Select AHBC bus clk for SERCOM0*/
    UINT32  u32Peripheral = (SERCOM_SPI_REGBASE & 0x0000ff00) >> 10;
    REGDW(APBCREG) |= (1 << u32Peripheral);

    /* Select Generater0 and set CLK enable bit*/
    REGW(GCLKCTLREG) =
        (
            CLKCTRL_ID(SERCOM0_GCLK_ID_CORE) |
            CLKCTRL_GEN(CLKCTRL_GEN_GCLK0_Val) |
            (CLKCTRL_CLKEN)
        );

    /* Wait Until SYNCBUSY bit to clear*/
    while((REGW(SERCOMSPI_STATUS)) & STATUS_SYNCBUSY);
}

/******************************************************************************
 * Function:        void SPI_Init (void)
 * Input:           SERCOM number (by default set to SERCOM0)
 * Output:          None					
 * Overview:        This routine initilizes SPI module registers ,GCLK module				
 * Note:            
 *****************************************************************************/
void SPI_Init(void)
{
    /* GCLK Init for SPI*/
    SPI_ClkInit();

    /* SPI Registers Initialization for SPI master */
    SPI_SyncInit();

    /* SPI Pad Mapping for SPI master */
    SPI_PortInit(); /*SERCOM pads configured as per DEV Rev C and E*/

    /*SPI_0_PORT_init(); */

    /* Enable SPI Master */
    SPI_SyncEnable();
}
