/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include "psf_stdinc.h"
#include <Timers.h>

/******************************************************************************
 * Function:        TC0_Hnadler()
 * Input:           None
 * Output:          None					
 * Overview:        This routine called when timer interrupt fires			
 * Note:            
 *****************************************************************************/ 
void TC0_Handler()
{
    /* Set the Timer Overflow interrupt*/
    REGB(TC0_INTFLAG) = TC0_INTENSET_OVF;
    /* Call the PD timer interrupt handler to serve PD functions*/
    MchpPSF_PDTimerISR();
#if VALIDATION
    u8GPIOVal = ~u8GPIOVal;
	
	//todo: below statement is throwing compilation error
    //GPIO_SetPinLevel(UINT8 u8pin ,u8GPIOVal);
#endif
}

/******************************************************************************
 * Function:        Timer_Init()
 * Input:           None
 * Output:          None					
 * Overview:        This routine initilizes Timer module				
 * Note:            
 *****************************************************************************/ 
 UINT8 Timer_Init(void)
 {
     /* Select AHBC bus clk for SERCOM1*/
    UINT32 u32Peripheral = (TC0_REG_ADDR & PHERIPHERAL_SEL_MASK) >> PHERIPHERAL_SEL_SERCOM;    
    REGDW(APBCREG) |= (1 << u32Peripheral);
    
    /* Select Generater0 and set CLK enable bit*/
    REGW(TC0_GCLKCTLREG) = (TC0_GCLK_ENABLE |TC0_CLKCTRL_GEN | TC0_CLKCTRL_CLKEN);
 
    /* Set timer enable bit*/
    REGDW(TC0_CTRLA) = (TC0_CTRLA_MODE_COUNT8 |TC0_CTRLA_WAVEGEN_NFRQ | TC0_CTRLA_PRESCALER | TC0_CTRLA_PRESCSYNC_MSK );
    //REGW(TC0_DBGCTRL) = TC0_DBGCTRL_DBGRUN;
    REGW(TC0_EVCTRL)  = TC0_EVCTRL_MASK;
    /* Set the Timer value to trigger 1ms*/
    REGB(TC0_COUNT8_PER) = TC0_PERIOD_REGISTER_VAL;
    REGB(TC0_COUNT8_CC0) =TC0_CC1_CC2_VALUE;
    REGB(TC0_COUNT8_CC1) =TC0_CC1_CC2_VALUE;	
    REGB(TC0_INTENSET) = TC0_INTENSET_OVF;
    /* Enable timer interrupt*/	
    REGDW(TC0_INTSET_ENABLE_REG) = TC0_ENABLE_INTERRUPT;
    /* Start the timer*/
    /* Set timer enable bit*/
    REGB(TC0_CTRLA) |= TC0_CTRLA_ENABLE;
    
    return 0;
 }