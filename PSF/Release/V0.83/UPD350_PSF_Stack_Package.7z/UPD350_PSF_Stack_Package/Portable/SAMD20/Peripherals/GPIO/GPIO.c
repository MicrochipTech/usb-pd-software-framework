/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include "psf_stdinc.h"
#include <GPIO.h>

/******************************************************************************
 * Function:        void IRQ_ResetUPD350ThruGPIOInit(UINT8 u8Portnum)
 * Input:           u8Portnum - Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
 * Output:          none					
 * Overview:        This routine Set the GPIO PIN function
 * Note:            
 *****************************************************************************/
void IRQ_ResetUPD350ThruGPIOInit(UINT8 u8Portnum)
{
    /*current implemetaion supports common reset pin for all ports. 
     * Hence reset for only port 0. 
     * New implementaion should support one reset pin for each port.*/
    if(0 == u8Portnum)
    {
        GPIO_SetDirection(PIN_PA00, GPIO_SETDIRECTION_IN);
        GPIO_SetPullMode(PIN_PA00, GPIO_PULLUP);
    }
}

/******************************************************************************
 * Function:        void GPIO_SetPinFunction()
 * Input:           GPIO PIN and Pin funnction
 * Output:          none					
 * Overview:        This routine Set the GPIO PIN function
 * Note:            
 *****************************************************************************/
void GPIO_SetPinFunction(UINT32 u8Pin, UINT32 u32Function)
{
    UINT8 u8PinIndex  = GPIOPIN(u8Pin);
    UINT8 u8MuxIndex = u8Pin >> (UINT8)1u;
    /* Check the Pin function*/
    if (GPIO_PIN_FUNC_OFF == u32Function)
    {
        /* Clear the Mux enable bit*/
        REGB(GPIO_PINCFG_REG_ADDR(u8PinIndex))&= ~GPIO_PINCFG_PMUXEN;
    } 
    else 
    {      
        /* Set the Mux enable bit*/
        REGB(GPIO_PINCFG_REG_ADDR(u8PinIndex))|= GPIO_PINCFG_PMUXEN;
        if (u8Pin & 1) 
        {
            /* Odd numbered pin */
            REGB(GPIO_PMUX_REG_ADDR(u8MuxIndex)) &= ~GPIO_PMUX_PMUXO_MSK;
            REGB(GPIO_PMUX_REG_ADDR(u8MuxIndex))|= GPIO_PMUX_PMUXO(u32Function);			
        } 
        else 
        {
            /* Even numbered pin */
            REGB(GPIO_PMUX_REG_ADDR(u8MuxIndex))&= ~GPIO_PMUX_PMUXE_MSK;
            REGB(GPIO_PMUX_REG_ADDR(u8MuxIndex))|= GPIO_PMUX_PMUXE(u32Function);	
        }
    }	
}

/******************************************************************************
 * Function:        void GPIO_SetPullMode()
 * Input:           GPIO PIN and Pull mode
 * Output:          none					
 * Overview:        This routine Set the Pullup/pulldown mode
 * Note:            
 *****************************************************************************/
void GPIO_SetPullMode(UINT8 u8Pin,UINT8 u8Pullmode)
{
    UINT32 u8Mask = (1U << u8Pin);
    UINT32 u32PinIndex = GPIOPIN(u8Pin);
    
    switch (u8Pullmode)
    {
      case GPIO_PULLOFF:
        /* Clear the PULL Enable bit in PINCFG register*/
        REGB(GPIO_PINCFG_REG_ADDR(u32PinIndex)) &= ~GPIO_PINCFG_PULLEN;
        break;
	
      case GPIO_PULLUP:	
         /* Clear DIR reg to make as input */
        REGDW(GPIO_DIRCLR_REG_ADDR) = u8Mask;	
        /*Set the PULL Enable bit*/ 
        REGB(GPIO_PINCFG_REG_ADDR(u32PinIndex)) |= GPIO_PINCFG_PULLEN;
        /*Set the OUTSET register to set as PULLUP*/             
        REGDW(GPIO_OUTSET_REG_ADDR) = u8Mask;	
        break;

      case GPIO_PULLDOWN:	
        REGDW(GPIO_DIRCLR_REG_ADDR) = u8Mask;
        /*Set the PULL Enable bit*/            
        REGB(GPIO_PINCFG_REG_ADDR(u32PinIndex)) |= GPIO_PINCFG_PULLEN;
        /* Clear the direction to make as PUll down*/            
        REGDW(GPIO_OUTCLR_REG_ADDR) = u8Mask;
        break;
            
      default:		
         break;
	}
}

/******************************************************************************
 * Function:        void GPIO_SetDirection()
 * Input:           GPIO PIN and direction
 * Output:          none					
 * Overview:        This routine Set GPIO PIN direction
 * Note:            
 *****************************************************************************/
void GPIO_SetDirection(UINT8 u8pin,UINT8 u8direction)
{
    UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));	
    switch (u8direction)
    {
    case GPIO_SETDIRECTION_OFF:	
      /* Set the DIRCLR register to Clear the Direction */
      REGDW(GPIO_DIRCLR_REG_ADDR) = u32mask;
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG |((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
      break;

    case GPIO_SETDIRECTION_IN:
      /* Set the DIRCLR register to Set as Input*/
      REGDW(GPIO_DIRCLR_REG_ADDR) = u32mask;
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN |((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
      break;
      
    case GPIO_SET_TRISTATE:
      REGDW(GPIO_DIRCLR_REG_ADDR) = u32mask;
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN |((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
      break;

    case GPIO_SETDIRECTION_OUT:
      /* Set the DIRSET register to Set as Output*/
      REGDW(GPIO_DIRSET_REG_ADDR) = u32mask;
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG | ((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
      break;

    default:
      break;
      }
}

/******************************************************************************
 * Function:        void GPIO_SetPinLevel()
 * Input:           GPIO Pin and output level
 * Output:          none					
 * Overview:        This routine Set GPIO PIN output level
 * Note:            
 *****************************************************************************/
void GPIO_SetPinLevel(UINT8 u8pin ,UINT8 u8level)
{
    UINT32 u32mask = 1U << GPIOPIN(u8pin);
    
    if(u8level)
      /* Set the output level in OUTSET register*/
      REGDW(GPIO_OUTSET_REG_ADDR) = u32mask;	
    else
      /* clear OUT register*/
      REGDW(GPIO_OUTCLR_REG_ADDR) = u32mask;
}

/******************************************************************************
 * Function:        void GPIO_GetPinLevel()
 * Input:           GPIO Pin 
 * Output:          none					
 * Overview:        This routine GPIO PIN level
 * Note:            
 *****************************************************************************/
UINT8 GPIO_GetPinLevel(UINT8 u8pin)
{
    UINT32 u32PinLevel;
    UINT32 u32Dir =0;
    UINT32 u32mask = 1U << GPIOPIN(u8pin);
    /* Read DIR register*/
    u32Dir = (REGDW(GPIO_DIR_REG_ADDR) &u32mask);	
    u32PinLevel = (REGDW(GPIO_IN_REG_ADDR) & ~u32Dir);
    u32PinLevel |= (REGDW(GPIO_OUT_REG_ADDR) & u32Dir);      
    return (UINT8)u32PinLevel;
}


void GPIOStrap_SetTristate(UINT8 u8pin)
{
      UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN |((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
}


UINT8 GPIOStrap_GetInputLevel(UINT8 u8pin)
{
    UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));
     
    return ((UINT8)((REGDW(GPIO_IN_REG_ADDR) & u32mask) > 0) ? 1 : 0);
}