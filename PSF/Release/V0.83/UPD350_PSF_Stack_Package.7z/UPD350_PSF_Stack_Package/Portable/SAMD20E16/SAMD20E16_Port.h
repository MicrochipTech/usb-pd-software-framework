/*******************************************************************************
  SAMD20E16 HAL porting Header File

  Company:
    Microchip Technology Inc.

  File Name:
    SAMD20E16_Port.h

  Summary:
    SAMD20E16 HAL Porting To PSF Header file.

  Description:
    This file contains provides the HAL drivers required for PSF Porting and integration. 
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END

#ifndef _SAMD20E16_PORT_H    /* Guard against multiple inclusion */
#define _SAMD20E16_PORT_H

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */
#include <stdbool.h>
#include <stddef.h>
#include <psf_stdinc.h>
#include "../../firmware/src/config/default/peripheral/tc/plib_tc0.h"
#include "../../firmware/src/config/default/peripheral/sercom/spim/plib_sercom0_spi.h"
#include "../../firmware/src/config/default/peripheral/port/plib_port.h"
#include "../../firmware/src/config/default/peripheral/eic/plib_eic.h"

// *****************************************************************************
// *****************************************************************************
// Section: Interface Functions
// *****************************************************************************
// *****************************************************************************
/****************************************************************************
    Function:
        

    Summary:
         

    Description:
       
    Conditions:
       
    Input:
        None

    Return:
        None

    Remarks:
        None

**************************************************************************************************/

UINT8 SAMD20_HWTimerInit(void);
void SAMD20_HWTimerCallback(TC_TIMER_STATUS status, uintptr_t context);


void SAMD20_SPIReaddriver (UINT8 u8PortNum, UINT8 *pu8ReadBuffer, UINT16 u16Readlength);
void SAMD20_SPIWritedriver (UINT8 u8PortNum, UINT8 *pu8WriteBuffer, UINT16 u16Writelength);
void SAMD20_DriveChipSelectLow(UINT8 u8PortNum);
void SAMD20_DriveChipSelectHigh(UINT8 u8PortNum);


void SAMD20_UPD350AlertInit(UINT8 u8PortNum);
void SAMD20_UPD350AlertCallback(uintptr_t u8PortNum);


void SAMD20_ResetUPD350(UINT8 u8PortNum);
void SAMD20_UPD350ResetGPIOInit(UINT8 u8PortNum);


void SAMD20_EnterCriticalSection();
void SAMD20_ExitCriticalSection();
void* SAMD20_MemCpy(void *dest, const void *src, int n);
int SAMD20_MemCmp(const void *pau8Data1, const void *pau8Data2, int len);



#endif /*_SAMD20E16_PORT_H */

/* *****************************************************************************
 End of File
 */
