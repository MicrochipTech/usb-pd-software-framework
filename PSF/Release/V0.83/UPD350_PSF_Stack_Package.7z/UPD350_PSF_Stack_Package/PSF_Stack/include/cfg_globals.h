/*******************************************************************************
  Configurable globals Header File

  Company:
    Microchip Technology Inc.

  File Name:
    cfg_globals.h

  Summary:
    Configurable globals header file

  Description:
    This file contains user configurable globals and functions. 
 *******************************************************************************/
/*******************************************************************************
Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#ifndef _CFG_GLOBALS_H_
#define _CFG_GLOBALS_H_

// *****************************************************************************
// *****************************************************************************
// Section: Data types and constants
// *****************************************************************************
// *****************************************************************************

extern PORT_CONFIG_DATA gasPortConfigurationData[CONFIG_PD_PORT_COUNT];

extern UPD_PIO_CONFIG_DATA const gasUpdPioConfigData[CONFIG_PD_PORT_COUNT];

// *****************************************************************************
// *****************************************************************************
//  Section: Interface Routines
// *****************************************************************************
// *****************************************************************************

/****************************************************************************
    Function:
        UINT8 MchpPSF_Init(void)

    Summary:
        PSF Stack initialisation API 

    Devices Supported:
        UPD350 REV A

    Description:
        This API should be called by the SOC layer to initialize the 
        PSF stack and UPD350.

    Conditions:
        API should be called before MchpPSF_RUN().

    Input:
        None

    Return:
        UINT8 - Returns a UINT8; For the current PSF implementation,API returns NULL.

    Remarks:
        None

**************************************************************************************************/
UINT8 MchpPSF_Init();

/**************************************************************************************************
    Function:
        void MchpPSF_RUN(void)

    Summary:
        PSF Stack state machine run API

    Devices Supported:
        UPD350 REV A

    Description:
        This API is to run the PSF state machine. 
        For single threaded environment, it should be called repeatedly within a while(1).
        Multi threaded Free RTOS environment is untested and latency of API call is to
        identified yet. 

    Conditions:
        API should be called only after MchpPSF_Init().

    Input:
        None

    Return:
        None

    Remarks:
        None

**************************************************************************************************/
void MchpPSF_RUN();

//TBD: Muthu, Description to be added
void MchpPSF_UPDAlertISR(UINT8 u8PortNum);

void MchpPSF_PDTimerISR();

#endif /*_CFG_GLOBALS_H_*/

