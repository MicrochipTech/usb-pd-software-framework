
#include <hal_atomic.h>
#include <hpl_init.h>
#include <psf_stdinc.h>


int main()
{
   
    MCU_Init();

    (void)MchpPSF_Init();
    
    while(TRUE)
    {   
        MchpPSF_RUN();
        
    }

    return TRUE;
}
