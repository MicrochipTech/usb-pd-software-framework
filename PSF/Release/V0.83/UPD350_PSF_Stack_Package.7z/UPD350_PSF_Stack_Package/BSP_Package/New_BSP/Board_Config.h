
/*******************************************************************************
  Board stack configuration

  Company:
    Microchip Technology Inc.

  File Name:
    BoardConfig.h

  Summary:
    Board configuration header file

  Description:
    This header file contains the configuration parameters of zeus stack to configures the Power delivery modules
*******************************************************************************/
//DOM-IGNORE-BEGIN
/*******************************************************************************

Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

********************************************************************************

*******************************************************************************/
#ifndef _PSF_BOARD_CONFIG_H_
#define _PSF_BOARD_CONFIG_H_

//DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: File includes - USER_APPLICATION FILES CAN GO HERE
// *****************************************************************************
// *****************************************************************************



/**************************************************************************
  Description:
    BOARD_CONFIG_DCDC_CTRL?? .

  Remarks:
    None.
  Example:
    <code>
    #define BOARD_CONFIG_DCDC_CTRL    PWRCTRL_DEFAULT_PSF_GPIO_CONFIG
	#define BOARD_CONFIG_DCDC_CTRL    
    </code>
                                                                           
  **************************************************************************/
#define BOARD_CONFIG_DCDC_CTRL        PWRCTRL_DEFAULT_PSF_GPIO_CONFIG

											  											  
// *****************************************************************************
// *****************************************************************************
// Section: PIO configurations
// *****************************************************************************
// *****************************************************************************

/* User Config Structure: This structure contains the user configure variables and PDOs*/

typedef struct _Upd_Pio_Config
{   
	UINT8   u8VBUSEnPio;        //PIO for UPD350  VBus Enable pin
    UINT8   u8VBUSEnPioMode;    // VBUS enable PIO mode
	UINT8   u8FaultInPio;       //PIO for UPD350 Port Control selection pin
    UINT8   u8FaultInMode;      //Fault In PIO mode, active high or active low etc.
    UINT8   u8VBUSDisPio;       // PIO to discharge VBUS
    UINT8   u8VBUSDisPioMode;   // VBUS discharger PIO mode, active high or active low etc.
    UINT8   u8DcDcEnPio;        // DC_DC_EN PIO for controlling the DC_DC enable
    UINT8   u8DcDcEnPioMode;    // DC_DC_EN PIO mode
    UINT8   u8VSELPio[3];       // VSEL[2:0] PIO for controlling GPIO based DC_DC
    UINT8   u8VSELPioMode[3];   // VSEL[2:0] PIO mode
    UINT8   u8VSELmapforPDO[8]; // VSEL map value corresponding to each PDO
}UPD_PIO_CONFIG_DATA;


/**************************************************************************************************
	Description:
	CONFIG_PORT_n_EN_VBUS_UPD_PIO refers to the PIO number of EN_VBUS pin for the nth Port.
	n can take values between 0 and CONFIG_PD_PORT_COUNT - 1.

	Remarks:
	Confined to INCLUDE_POWER_FAULT_HANDLING define.

	Example:
	<code>
	#define CONFIG_PORT_0_UPD_EN_VBUS		2
	</code>
**************************************************************************************************/
											  
#define CONFIG_PORT_0_UPD_EN_VBUS                   eUPD_PIO2
#define CONFIG_PORT_1_UPD_EN_VBUS                   eUPD_PIO3

typedef enum
{
    ePUSH_PULL_ACTIVE_HIGH       = 0x0CU,
    ePUSH_PULL_ACTIVE_LOW        = 0x04U,
    eOPEN_DRAIN_ACTIVE_HIGH      = 0x08U,
    eOPEN_DRAIN_ACTIVE_LOW       = 0x00U,
    eOPEN_DRAIN_ACTIVE_HIGH_PU   = 0x88U,
    eOPEN_DRAIN_ACTIVE_LOW_PU    = 0x80U
}eUPD_OUTPUT_PIN_MODES_TYPE;

#define CONFIG_PORT_0_UPD_EN_VBUS_PIO_MODE          ePUSH_PULL_ACTIVE_HIGH
#define CONFIG_PORT_1_UPD_EN_VBUS_PIO_MODE          ePUSH_PULL_ACTIVE_HIGH

#define CONFIG_PORT_0_UPD_VBUS_DIS_PIO_NO           eUPD_PIO8
#define CONFIG_PORT_1_UPD_VBUS_DIS_PIO_NO           eUPD_PIO4

#define CONFIG_PORT_0_UPD_VBUS_DIS_PIO_MODE         ePUSH_PULL_ACTIVE_HIGH
#define CONFIG_PORT_1_UPD_VBUS_DIS_PIO_MODE         ePUSH_PULL_ACTIVE_HIGH

#define CONFIG_PORT_0_UPD_DC_DC_EN_PIO_NO           eUPD_PIO_UN_DEF
#define CONFIG_PORT_1_UPD_DC_DC_EN_PIO_NO           eUPD_PIO6

#define CONFIG_PORT_0_UPD_DC_DC_EN_PIO_MODE         ePUSH_PULL_ACTIVE_HIGH
#define CONFIG_PORT_1_UPD_DC_DC_EN_PIO_MODE         ePUSH_PULL_ACTIVE_HIGH

#define CONFIG_PORT_0_UPD_VSEL0_PIO_NO              eUPD_PIO_UN_DEF
#define CONFIG_PORT_1_UPD_VSEL0_PIO_NO              eUPD_PIO7

#define CONFIG_PORT_0_UPD_VSEL0_PIO_MODE            ePUSH_PULL_ACTIVE_HIGH
#define CONFIG_PORT_1_UPD_VSEL0_PIO_MODE            ePUSH_PULL_ACTIVE_HIGH

#define CONFIG_PORT_0_UPD_VSEL1_PIO_NO              eUPD_PIO_UN_DEF
#define CONFIG_PORT_1_UPD_VSEL1_PIO_NO              eUPD_PIO8

#define CONFIG_PORT_0_UPD_VSEL1_PIO_MODE            ePUSH_PULL_ACTIVE_HIGH
#define CONFIG_PORT_1_UPD_VSEL1_PIO_MODE            ePUSH_PULL_ACTIVE_HIGH

#define CONFIG_PORT_0_UPD_VSEL2_PIO_NO              eUPD_PIO_UN_DEF
#define CONFIG_PORT_1_UPD_VSEL2_PIO_NO              eUPD_PIO9

#define CONFIG_PORT_0_UPD_VSEL2_PIO_MODE            ePUSH_PULL_ACTIVE_HIGH
#define CONFIG_PORT_1_UPD_VSEL2_PIO_MODE            ePUSH_PULL_ACTIVE_HIGH

#define CONFIG_PORT_0_VSAFE0V_VSEL_MAPPING  0x00
#define CONFIG_PORT_0_PDO_1_VSEL_MAPPING    0x00
#define CONFIG_PORT_0_PDO_2_VSEL_MAPPING    0x01
#define CONFIG_PORT_0_PDO_3_VSEL_MAPPING    0x02
#define CONFIG_PORT_0_PDO_4_VSEL_MAPPING    0x04
#define CONFIG_PORT_0_PDO_5_VSEL_MAPPING    0x00
#define CONFIG_PORT_0_PDO_6_VSEL_MAPPING    0x00
#define CONFIG_PORT_0_PDO_7_VSEL_MAPPING    0x00

#define CONFIG_PORT_1_VSAFE0V_VSEL_MAPPING  0x00
#define CONFIG_PORT_1_PDO_1_VSEL_MAPPING    0x00
#define CONFIG_PORT_1_PDO_2_VSEL_MAPPING    0x01
#define CONFIG_PORT_1_PDO_3_VSEL_MAPPING    0x02
#define CONFIG_PORT_1_PDO_4_VSEL_MAPPING    0x04
#define CONFIG_PORT_1_PDO_5_VSEL_MAPPING    0x00
#define CONFIG_PORT_1_PDO_6_VSEL_MAPPING    0x00
#define CONFIG_PORT_1_PDO_7_VSEL_MAPPING    0x00

/**************************************************************************************************
	Description:
	CONFIG_PORT_n_PRT_CTL_OCS_UPD_PIO refers to the PIO number of PRT_CTL/OCS pin for the nth Port.
	n can take values between 0 and CONFIG_PD_PORT_COUNT - 1.

	Remarks:
	Confined to INCLUDE_POWER_FAULT_HANDLING define.

	Example:
	<code>
	#define CONFIG_PORT_0_UPD_FAULT_IN		9
	</code>
**************************************************************************************************/
											 											  
#define CONFIG_PORT_0_UPD_FAULT_IN_PIO_NO               eUPD_PIO9
#define CONFIG_PORT_1_UPD_FAULT_IN_PIO_NO               eUPD_PIO5


typedef enum
{
    eFAULT_IN_ACTIVE_LOW         = 0x20U,
    eFAULT_IN_ACTIVE_HIGH        = 0x10U,
    eFAULT_IN_ACTIVE_LOW_PU      = 0xA0U,
    eFAULT_IN_ACTIVE_HIGH_PD     = 0x50U
}eFAULT_IN_MODE_TYPE;

#define CONFIG_PORT_0_UPD_FAULT_IN_MODE               eFAULT_IN_ACTIVE_LOW
#define CONFIG_PORT_1_UPD_FAULT_IN_MODE               eFAULT_IN_ACTIVE_LOW

											 
#endif
