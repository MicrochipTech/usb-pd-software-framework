/*******************************************************************************

Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
/*******************************************************************************
  File Name:
    portpower_control.c

  Summary:
    File Summary

  Description:
    Short one line description
*******************************************************************************/


#include <stdinc.h>
#ifdef AMAZON
#include <dac.h>
#endif

static void UPD_GPIOGenericOutputInit(UINT8 u8PortNum,UINT8 u8PIONum, UINT8 u8PioMode);

static void UPD_GPIOGenericOutputInit(UINT8 u8PortNum,UINT8 u8PIONum, UINT8 u8PioMode)
{
    if ((UINT8)eUPD_PIO_UN_DEF != u8PIONum)
    {
        /*clear bits 6:4 and 1:0 in the read value to avoid invalid combinations.*/
        u8PioMode &= (UPD_CFG_PIO_PULL_UP_ENABLE | UPD_CFG_PIO_DATAOUTPUT | UPD_CFG_PIO_BUFFER_TYPE);
        /*enable GPIO and direction as output*/
        u8PioMode |= (UPD_CFG_PIO_DIRECTION | UPD_CFG_PIO_GPIO_ENABLE);
        /*de-assert the pin*/
        u8PioMode ^= UPD_CFG_PIO_DATAOUTPUT;
        /*update the value to GPIO register.*/
        UPD_RegWriteByte(u8PortNum, UPD_CFG_PIO_REGADDR(u8PIONum), u8PioMode);
    }
}
/***********************************************************************************/

void PWRCTRL_initialization(UINT8 u8PortNum)
{
  

    UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, \
                                    gasUpdPioConfigData[u8PortNum].u8VBUSEnPioMode);

    UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, \
                                        gasUpdPioConfigData[u8PortNum].u8VBUSDisPioMode);
#ifdef AMAZON
    if (u8PortNum == PORT0)
    {
        (void)DAC_Initialization();
        return;
    }
#endif

    UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8DcDcEnPio, \
                                    gasUpdPioConfigData[u8PortNum].u8DcDcEnPioMode);
    
    for(UINT8 u8VSELIndex = SET_TO_ZERO; u8VSELIndex < PWRCTRL_VSEL_PIO_MAX_COUNT; u8VSELIndex++)
    {
        UPD_GPIOGenericOutputInit(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSELPio[u8VSELIndex], \
                                gasUpdPioConfigData[u8PortNum].u8VSELPioMode[u8VSELIndex]);
    }

    UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8DcDcEnPio, \
                gasUpdPioConfigData[u8PortNum].u8DcDcEnPioMode, (UINT8)UPD_GPIO_ASSERT);
    

}
/************************************************************************************/
void PWRCTRL_SetPortPower (UINT8 u8PortNum, UINT8 u8PDOIndex, UINT16 u16VBUSVoltage, UINT16 u16Current)
{
    UINT8 u8EnVbusMode = gasUpdPioConfigData[u8PortNum].u8VBUSEnPioMode;
    
    if (PWRCTRL_VBUS_0V == u16VBUSVoltage)
    {
        /*Deassert VBUS_EN if voltage is 0V*/
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, 
                u8EnVbusMode, (UINT8)UPD_GPIO_DE_ASSERT);
    }
    else
    {
        /*Assert VBUS_EN*/
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSEnPio, 
                u8EnVbusMode, (UINT8)UPD_GPIO_ASSERT);
    }
    
    #ifdef AMAZON
    if (u8PortNum == PORT0)
    {
        (void)DAC_DriveVoltage(u16VBUSVoltage);
        return;
    }
    #endif
    
    for(UINT8 u8VSELIndex = SET_TO_ZERO; u8VSELIndex < PWRCTRL_VSEL_PIO_MAX_COUNT; u8VSELIndex++)
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VSELPio[u8VSELIndex], \
            gasUpdPioConfigData[u8PortNum].u8VSELPioMode[u8VSELIndex], \
            (((gasUpdPioConfigData[u8PortNum].u8VSELmapforPDO[u8PDOIndex] & BIT(u8VSELIndex)) == BIT(u8VSELIndex)) \
            ? (UINT8)UPD_GPIO_ASSERT : (UINT8)UPD_GPIO_DE_ASSERT));
    } 
}
/************************************************************************************/
void PWRCTRL_ConfigVBUSDischarge (UINT8 u8PortNum, UINT8 u8EnaDisVBUSDIS)
{
    UINT8 u8VbusDisMode = gasUpdPioConfigData[u8PortNum].u8VBUSDisPioMode;
    
    if (u8EnaDisVBUSDIS == PWRCTRL_ENABLE_VBUSDIS )
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, \
                u8VbusDisMode, (UINT8)UPD_GPIO_ASSERT);
    }
    else
    {
        UPD_GPIOUpdateOutput(u8PortNum, gasUpdPioConfigData[u8PortNum].u8VBUSDisPio, \
                u8VbusDisMode, (UINT8)UPD_GPIO_DE_ASSERT);
    }

}

/************************************************************************************/
