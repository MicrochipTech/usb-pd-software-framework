/*******************************************************************************
Copyright �  [2019] Microchip Technology Inc. and its subsidiaries.

Subject to your compliance with these terms, you may use Microchip software and
any derivatives exclusively with Microchip products. It is your responsibility
to comply with third party license terms applicable to your use of third party
software (including open source software) that may accompany Microchip software.

THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER EXPRESS,
IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES
OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN
ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST
EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU
HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

#include <stdinc.h>

/*******************************************************************/
/******************* Functions**************************************/
/*******************************************************************/

UINT8 MchpPSF_Init(void)
{
    UINT8 u8InitStatus = 1;
       
    /*Timer module Initialization*/
    (void)PDTimer_Init();
    
    /*Initialize HW SPI module defined by the user*/
    CONFIG_HOOK_UPD_HW_INTF_INIT();
    
    for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
    {
        /*UPD350 Reset GPIO Init*/
        CONFIG_HOOK_HW_UPDRESETGPIO_INIT(u8PortNum);
    }
 
	
	/*Initialize Internal global variables*/
    IntGlobals_PDInitialization();
    
    UPD_CheckAndDisablePorts();
    
    MCHP_PSF_HOOK_PORTS_ENDIS(&gau8PortDisable[0],&gasPortConfigurationData[0]);
    
    /* VBUS threshold correction factor */
    UPD_FindVBusCorrectionFactor();
    
    /*Initialize debug hardware*/
    CONFIG_HOOK_DEBUG_INIT();
    
    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
    
    CONFIG_HOOK_GPIO_INT_HW_INIT();
    
    for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
    {
        if (PORT_STATUS_ENABLED == gau8PortDisable[u8PortNum])
        {
            /*User defined UPD Interrupt Initialization for MCU*/
            CONFIG_HOOK_HW_UPDALERTGPIO_INIT(u8PortNum);
            
            /*Port Power Intialisation*/
            CONFIG_HOOK_HW_PORTPWR_INIT(u8PortNum);
        }
    }
	    
    DPM_StateMachineInit();  

    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
    
    return u8InitStatus;

}
/********************************************************************************************/
void MchpPSF_RUN()
{
	for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
  	{
          if (PORT_STATUS_ENABLED == gau8PortDisable[u8PortNum])
          {
             DPM_RunStateMachine (u8PortNum);
              
			#if INCLUDE_POWER_MANAGEMENT_CTRL
                
            UPD_PwrManagementCtrl (u8PortNum);
                       
			#endif
      
          }
	}
}
/*********************************************************************************************/

/*********************************************************************************************/
void MchpPSF_UPDAlertISR(UINT8 u8PortNum)
{
    UPDIntr_AlertHandler(u8PortNum);
}
/*********************************************************************************************/

/*********************************************************************************************/
void MchpPSF_PDTimerISR()
{
    PDTimer_InterruptHandler();
}
/*********************************************************************************************/

