/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include <stdinc.h>
#include "Interrupts.h"


/******************************************************************************
 * Function:        EIC_Handler()
 * Input:           None
 * Output:          None					
 * Overview:        This routine called when external interuupt triggered for UPD port				
 * Note:            
 *****************************************************************************/
 void EIC_Handler(void)
 {
     /* Clear the Interuupt*/
    volatile UINT32 u32Intflag = REGDW(INT_EIC_INTFLAG);
    REGDW(INT_EIC_INTFLAG) = u32Intflag;
    
    /* Check if Port0 Interupt*/
    if(u32Intflag & INT_EXT_INT14)
    {
        MchpPSF_UPDAlertISR (0);
    }
    
    /* Check if Port1 Interupt*/
    if(u32Intflag & INT_EXT_INT15)
    {
        MchpPSF_UPDAlertISR (1);
    }
    u32Intflag = REGDW(INT_EIC_INTFLAG);
    REGDW(INT_EIC_INTFLAG) = u32Intflag;
 }

 /******************************************************************************
 * Function:        INT_ExtIrqHwInit()
 * Input:           None
 * Output:          None					
 * Overview:        This routine initilizes Interrupt controller module				
 * Note:            
 *****************************************************************************/ 
 void INT_ExtIrqHwInit(void)
 {
    /* Select Generater0 and set CLK enable bit*/
    REGW(GCLKCTLREG) = (GCLK_CLKCTRL_ID(INT_EICGCLK_ID) | GCLK_CLKCTRL_GEN(CLKCTRL_GEN_GCLK0_Val) | (CLKCTRL_CLKEN));
    REGB(INT_EIC_NMICTRL) = (INT_EIC_NMIFILT | INT_NMICTRL_NMISENSE );                  
    
    REGB(INT_EIC_CTRL) |= INT_CTRL_ENABLE;
    
    REGDW(INT_CLR_ENABLE_REG) = (1UL << INT_EIC_IRQN);    
    REGDW(INT_CLR_PENDING_REG) = (1UL << INT_EIC_IRQN);
    REGDW(INT_SET_ENABLE_REG) = (1UL << INT_EIC_IRQN);
 }
/******************************************************************************
 * Function:        INT_ExtIrqInit()
 * Input:           u8Portnum to which the Irq interrupt should be configured. 
 * Output:          None					
 * Overview:        This routine initializes Interrupt controller module				
 * Note:            
 *****************************************************************************/ 
 void INT_ExtIrqInit(UINT8 u8Portnum)
 {
    if (0 == u8Portnum)
    {
  		REGDW(INT_EIC_EVCTRL) |= INT_EIC_EXTINTEO14; 
        REGDW(INT_EIC_WAKEUP) |= INT_EIC_WAKEUPEN14;   
        REGDW(INT_EIC_CONFIG1) |= INT_CONFIG_FILTEN6| INT_CONFIG1_SENSE6;
        /*Set PA14 as IRQ0 line for Port 0 Internal UPD*/
        GPIO_SetDirection(PIN_PA14, GPIO_SETDIRECTION_IN);
        GPIO_SetPullMode(PIN_PA14,GPIO_PULLUP);
        GPIO_SetPinFunction(PIN_PA14, PINMUX_PA14A_EIC_EXTINT14);
        REGDW(INT_EIC_INTENSET)|=  INT_EXT_INT14;       
        //REGDW(INT_EIC_WAKEUP) |= INT_EXT_WUP14;
    }
    
    else if (1 == u8Portnum)
    { 
		REGDW(INT_EIC_EVCTRL) |= INT_EIC_EXTINTEO15;
        REGDW(INT_EIC_WAKEUP) |= INT_EIC_WAKEUPEN15;    
        REGDW(INT_EIC_CONFIG1) |= INT_CONFIG_FILTEN7| INT_CONFIG1_SENSE7;
        /*Set PA15 as IRQ1 line for Port 1 External UPD*/
        GPIO_SetDirection(PIN_PA15, GPIO_SETDIRECTION_IN);
        GPIO_SetPullMode(PIN_PA15,GPIO_PULLUP);
        GPIO_SetPinFunction(PIN_PA15, PINMUXPA15A_EIC_EXTINT15);       
        REGDW(INT_EIC_INTENSET)|=  INT_EXT_INT15;
        //REGDW(INT_EIC_WAKEUP) |= INT_EXT_WUP15;
    }
 }