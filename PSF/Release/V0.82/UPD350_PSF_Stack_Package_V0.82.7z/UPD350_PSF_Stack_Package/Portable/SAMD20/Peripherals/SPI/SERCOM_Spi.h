/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

/*******************************************************************************
  SERCOM SPI driver module Header

  Company:
    Microchip Technology Inc.

  File Name:
    SERCOM_SPI.h

  Summary:
    SERCOM SPI driver routines to communicate UPD350

  Description:
    This header file contains the function prototypes and definitions of the
    data types and constants that make up the interface to the Power delivery modules
*******************************************************************************/
#ifndef _SERCOM_SPI_H_
#define _SERCOM_SPI_H_
#include <GPIO.h>

/* todo john: to be moved to common file */

/* ========== SERCOM SPI GCLK control resiters ========== */
#define GCLKCTLREG              (0x40000C02)    /*brief (GCLK) APB Base Address */
#define APBCMASK_OFFSET         0x20
#define PMREG                   (0x40000400)    /* brief (PM) APB Base Address */
#define APBCREG                 (PMREG + APBCMASK_OFFSET)
#define CLKCTRL_ID_Pos          0           /* Generic Clock Selection ID */
#define CLKCTRL_ID_Msk          ((0x3F) << CLKCTRL_ID_Pos)
#define CLKCTRL_ID(value)       (CLKCTRL_ID_Msk & ((value) << CLKCTRL_ID_Pos))
#define CLKCTRL_GEN_Pos         8           /* Generic Clock Generator */
#define CLKCTRL_GEN_Msk         ((0xF) << CLKCTRL_GEN_Pos)
#define CLKCTRL_GEN(value)      (CLKCTRL_GEN_Msk & ((value) << CLKCTRL_GEN_Pos))
#define CLKCTRL_GEN_GCLK0_Val   (0x0)       /**< \brief (GCLK_CLKCTRL) Generic clock generator 0 */

/* ========== SERCOM Selection ========== */
#define SERCOM_BASE_ADD     (0x42000800)    /*  SERCOM base address*/
#define SERCOM_SEL_OFFSET   0x400           /*  SERCOM selection offset*/
#define SERCOM_CTRLREG_ADD(SercomSel) \
    SERCOM_BASE_ADD + (SercomSel * SERCOM_SEL_OFFSET)

/* todo john To move it common file */
#define SPI_SERCOM_SELECTION    0           /*  SERCOM selection*/
#define SERCOM_SPI_REGBASE      SERCOM_CTRLREG_ADD(SPI_SERCOM_SELECTION)

/* ========== SERCOM SPI control registers ========== */
#define SERCOMSPI_CTRLA             SERCOM_SPI_REGBASE  /*(SERCOM0) SPI Control A */
#define SERCOMSPI_CTRLB_OFFSET      (0x04)
#define SERCOMSPI_CTRLB             ((SERCOMSPI_CTRLA) + (SERCOMSPI_CTRLB_OFFSET))      /*(SERCOM0) SPI Control B */
#define SERCOMSPI_DBGCTRL_OFFSET    (0x04)
#define SERCOMSPI_DBGCTRL           (SERCOMSPI_CTRLB + SERCOMSPI_DBGCTRL_OFFSET)        /*(SERCOM0) SPI Debug Control */
#define SERCOMSPI_BAUD_OFFSET       (0x02)
#define SERCOMSPI_BAUD              (SERCOMSPI_DBGCTRL + SERCOMSPI_BAUD_OFFSET)         /*(SERCOM0) SPI Baud Rate */
#define SERCOMSPI_INTENCLR_OFFSET   (0x02)
#define SERCOMSPI_INTENCLR          (SERCOMSPI_BAUD + SERCOMSPI_INTENCLR_OFFSET)        /*(SERCOM0) SPI Interrupt Enable Clear */
#define SERCOMSPI_INTENSET_OFFSET   (0x01)
#define SERCOMSPI_INTENSET          (SERCOMSPI_INTENCLR + SERCOMSPI_INTENSET_OFFSET)    /*(SERCOM0) SPI Interrupt Enable Set */
#define SERCOMSPI_INTFLAG_OFFSET    (0x01)
#define SERCOMSPI_INTFLAG           (SERCOMSPI_INTENSET + SERCOMSPI_INTFLAG_OFFSET)     /*(SERCOM0) SPI Interrupt Flag Status and Clear */
#define SERCOMSPI_STATUS_OFFSET     (0x02)
#define SERCOMSPI_STATUS            (SERCOMSPI_INTFLAG + SERCOMSPI_STATUS_OFFSET)       /*(SERCOM0) SPI Status */
#define SERCOMSPI_ADDR_OFFSET       (0x04)
#define SERCOMSPI_ADDR              (SERCOMSPI_STATUS + SERCOMSPI_ADDR_OFFSET)          /*(SERCOM0) SPI Address */
#define SERCOMSPI_DATA_OFFSET       (0x04)

//#define SERCOMSPI_DATA       		(SERCOMSPI_ADDR + SERCOMSPI_DATA_OFFSET) /*(SERCOM0) SPI Data */
#define SERCOMSPI_DATA  (0x42000818)        /*(SERCOM0) SPI Data */

/* ========== Bit wise register access  ========== */
#define CTRLA_SWRST_Pos     0u              /* Software Reset */
#define CTRLA_SWRST         ((0x1) << CTRLA_SWRST_Pos)
#define CTRLA_ENABLE_Pos    1u              /*SERCOM SPI Enable */
#define CTRLA_ENABLE        ((0x1) << CTRLA_ENABLE_Pos)
#define CTRLA_IBON_Pos      8u              /*Immediate Buffer Overflow Notification */
#define CTRLA_IBON          ((0x1) << CTRLA_IBON_Pos)
#define CTRLA_DOPO_Pos      16u             /*(SERCOM_SPI_CTRLA) Data Out Pinout */
#define CTRLA_DOPO_Msk      ((0x3) << CTRLA_DOPO_Pos)
#define CTRLA_DOPO(value)   (CTRLA_DOPO_Msk & ((value) << CTRLA_DOPO_Pos))
#define CTRLA_DIPO_Pos      20u             /*(SERCOM_SPI_CTRLA) Data In Pinout */
#define CTRLA_DIPO_Msk      ((0x3) << CTRLA_DIPO_Pos)
#define CTRLA_DIPO(value)   (CTRLA_DIPO_Msk & ((value) << CTRLA_DIPO_Pos))
#define CTRLA_CPHA_Pos      28u             /*SPI transfer phase */
#define CTRLA_CPHA          ((0x1) << CTRLA_CPHA_Pos)
#define CTRLA_CPOL_Pos      29u             /*SPI transfer phase */
#define CTRLA_CPOL          ((0x1) << CTRLA_CPOL_Pos)
#define CTRLB_PLOADEN_Pos   6u              /*Slave Data Preload Enable */
#define CTRLB_PLOADEN       ((0x1) << CTRLB_PLOADEN_Pos)
#define CTRLB_AMODE_Pos     14u             /* Address Mode */
#define CTRLB_AMODE_Msk     ((0x3) << CTRLB_AMODE_Pos)
#define CTRLB_RXEN_Pos      17u             /* Receiver Enable */
#define CTRLB_RXEN          ((0x1) << CTRLB_RXEN_Pos)
#define BAUD_Pos            0u              /*Baud Register position */
#define BAUD_Msk            ((0xFF) << BAUD_Pos)
#define BAUDRATE(value)     (BAUD_Msk & ((value) << BAUD_Pos))
#define STATUS_BUFOVF_Pos   2u              /* (SERCOM_SPI_STATUS) Buffer Overflow */
#define STATUS_BUFOVF       ((0x1) << STATUS_BUFOVF_Pos)
#define STATUS_SYNCBUSY_Pos 15u             /* Synchronization Busy */
#define STATUS_SYNCBUSY     ((0x1) << STATUS_SYNCBUSY_Pos)
#define CLKCTRL_CLKEN_Pos   14              /*Clock Enable */
#define CLKCTRL_CLKEN       ((0x1) << CLKCTRL_CLKEN_Pos)
#define SPI_SLAVE_MODE      (0x2)           /* SPI slave mode */
#define SPI_MASTER_MODE     ((0x3) << (2u)) /* SPI Master mode */
#define BAUDRATE_8MHZ       0x02
#define BAUDRATE_12MHZ      0x01

/* ========== SERCOM SPI Intruppt register  ========== */
#define SERCOMSPI_INTFLAG_DRE_Pos   0       /*Data Register Empty */
#define SERCOMSPI_INTFLAG_DRE       ((0x1) << SERCOMSPI_INTFLAG_DRE_Pos)
#define SERCOMSPI_INTFLAG_TXC_Pos   1       /*Transmit Complete */
#define SERCOMSPI_INTFLAG_TXC       ((0x1) << SERCOMSPI_INTFLAG_TXC_Pos)
#define SERCOMSPI_INTFLAG_RXC_Pos   2       /* Receive Complete */
#define SERCOMSPI_INTFLAG_RXC       ((0x1) << SERCOMSPI_INTFLAG_RXC_Pos)
#define SERCOMSPI_INTFLAG_MASK      (0x07)  /* MASK Register */

/* ========== Instance parameters for SERCOM0 peripheral ========== */
#define SERCOM0_GCLK_ID_CORE    13
#define SERCOM0_GCLK_ID_SLOW    12
#define SERCOM0_INT_MSB         3
#define SERCOM0_PMSB            3
#define DUMMYBYTE               0xFF

/* ========== Instance parameters for SPI Validation ========== */
#define SPI_INIT_TEST       0x90
#define SPI_MODE_SEL_TEST   0x91
#define SPI_SPI_SPEED_TEST  0x92
#define SPI_STRESS_TEST     0x93

/* SPI Driver routines*/

/**************************************************************************************************

	Function:
	void SPI_Write(UINT8 u8PortNum, UINT8 *pu8WriteBuffer, UINT16 u8Writelength)

	Summary:
		Routine used to write UPD registers

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will write UPD registers for mentioned lengh of bytes

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_Write(UINT8 u8PortNum, UINT8 *pu8WriteBuffer, UINT16 u8Writelength);

/**************************************************************************************************

	Function:
	void SPI_Read (UINT8 u8PortNum, UINT8 *pu8ReadBuffer, UINT16 u8Readlength)

	Summary:
		Routine used to read UPD registers

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will read UPD registers for mentioned lengh of bytes

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_Read(UINT8 u8PortNum, UINT8 *pu8ReadBuffer, UINT16 u8Readlength);

/**************************************************************************************************
	Function:
	void SPI_Init (void)

	Summary:
		Initialize SPI module related initialization

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will initialize GCLK,Pad,registers

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_Init(void);

/**************************************************************************************************

	Function:
	void SPI_ClkInit (void)

	Summary:
		configure GCLK cmodule and initialize clk source , generators

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will configure GCLK cmodule and initialize clk source , generators

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_ClkInit(void);

/**************************************************************************************************

	Function:
	void SPI_PortInit (void)

	Summary:
		Initialize SPI port pad configurations

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will configure SPI port PADs(MOSI,MISO,SS,CLK)

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_PortInit(void);

/**************************************************************************************************

	Function:
	void SPI_SyncInit (void)

	Summary:
		Initialize SPI cnotrol registers

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will initialize the SPI control registers

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_SyncInit(void);

/**************************************************************************************************

	Function:
	void SPI_SyncEnable (void)

	Summary:
		Enables SPI module

	Devices Supported:
		UPD350 REV C&E

	Description:
		This API will enable SPI module synconization

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void    SPI_SyncEnable(void);
void    SPI_ChipSelectLow(UINT8 u8Portnum);
void    SPI_ChipSelectHigh(UINT8 u8Portnum);
#endif
